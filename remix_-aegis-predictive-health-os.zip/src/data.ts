/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HealthCenter, OperationalAlert, RedistributionTask } from './types';

export const INITIAL_HEALTH_CENTERS: HealthCenter[] = [
  {
    id: 'chc-hq',
    name: 'District HQ Hospital & CHC',
    type: 'CHC',
    location: { x: 50, y: 50 },
    patientFlow: 180,
    patientFlowTrend: 'rising',
    bedOccupancy: 88,
    doctorsAvailable: 9,
    doctorsTotal: 12,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 1200, minRequired: 400, unit: 'vials', depletionDays: 14, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 350, minRequired: 100, unit: 'vials', depletionDays: 18, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 2500, minRequired: 800, unit: 'sachets', depletionDays: 25, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 3000, minRequired: 600, unit: 'tablets', depletionDays: 20, status: 'optimal' },
    },
  },
  {
    id: 'phc-north',
    name: 'North Valley PHC',
    type: 'PHC',
    location: { x: 30, y: 15 },
    patientFlow: 65,
    patientFlowTrend: 'rising',
    bedOccupancy: 45,
    doctorsAvailable: 2,
    doctorsTotal: 2,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 35, minRequired: 150, unit: 'vials', depletionDays: 2, status: 'critical' },
      Insulin: { name: 'Insulin', stock: 80, minRequired: 50, unit: 'vials', depletionDays: 10, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 900, minRequired: 300, unit: 'sachets', depletionDays: 15, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 450, minRequired: 200, unit: 'tablets', depletionDays: 6, status: 'warning' },
    },
  },
  {
    id: 'phc-east',
    name: 'East Coast Riverside PHC',
    type: 'PHC',
    location: { x: 80, y: 35 },
    patientFlow: 80,
    patientFlowTrend: 'rising',
    bedOccupancy: 92,
    doctorsAvailable: 1,
    doctorsTotal: 3,
    labServicesActive: false, // Outage!
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 250, minRequired: 100, unit: 'vials', depletionDays: 12, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 15, minRequired: 40, unit: 'vials', depletionDays: 3, status: 'critical' },
      ORS: { name: 'ORS Packets', stock: 120, minRequired: 400, unit: 'sachets', depletionDays: 1, status: 'critical' }, // Monsoon dehydration spike
      Paracetamol: { name: 'Paracetamol', stock: 1100, minRequired: 300, unit: 'tablets', depletionDays: 14, status: 'optimal' },
    },
  },
  {
    id: 'chc-west',
    name: 'West Hill Foothills CHC',
    type: 'CHC',
    location: { x: 15, y: 65 },
    patientFlow: 110,
    patientFlowTrend: 'steady',
    bedOccupancy: 60,
    doctorsAvailable: 5,
    doctorsTotal: 6,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 800, minRequired: 300, unit: 'vials', depletionDays: 22, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 180, minRequired: 80, unit: 'vials', depletionDays: 15, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 1900, minRequired: 500, unit: 'sachets', depletionDays: 30, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 2400, minRequired: 500, unit: 'tablets', depletionDays: 18, status: 'optimal' },
    },
  },
  {
    id: 'phc-south',
    name: 'South Forest Border PHC',
    type: 'PHC',
    location: { x: 60, y: 80 },
    patientFlow: 45,
    patientFlowTrend: 'falling',
    bedOccupancy: 30,
    doctorsAvailable: 2,
    doctorsTotal: 2,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 180, minRequired: 100, unit: 'vials', depletionDays: 15, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 55, minRequired: 30, unit: 'vials', depletionDays: 12, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 600, minRequired: 200, unit: 'sachets', depletionDays: 18, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 150, minRequired: 150, unit: 'tablets', depletionDays: 3, status: 'warning' },
    },
  },
];

export const INITIAL_ALERTS: OperationalAlert[] = [
  {
    id: 'alert-1',
    centerId: 'phc-north',
    centerName: 'North Valley PHC',
    type: 'shortage',
    severity: 'critical',
    message: 'Amoxicillin stock (35 vials) is expected to deplete in 2 days based on rising patient flow.',
    metric: 'Medicine Inventory',
    recommendedAction: 'Redistribute 300 vials of Amoxicillin from West Hill Foothills CHC.',
  },
  {
    id: 'alert-2',
    centerId: 'phc-east',
    centerName: 'East Coast Riverside PHC',
    type: 'shortage',
    severity: 'critical',
    message: 'ORS Packets are critically low (120 units left) due to seasonal gastroenteritis spike.',
    metric: 'Medicine Inventory',
    recommendedAction: 'Urgent transfer of 800 ORS sachets from District HQ Hospital.',
  },
  {
    id: 'alert-3',
    centerId: 'phc-east',
    centerName: 'East Coast Riverside PHC',
    type: 'lab_offline',
    severity: 'warning',
    message: 'Primary clinical laboratory reported offline. Blood chemistry diagnostics unavailable.',
    metric: 'Laboratory Services',
    recommendedAction: 'Route emergency lab samples to District HQ Hospital.',
  },
  {
    id: 'alert-4',
    centerId: 'chc-hq',
    centerName: 'District HQ Hospital & CHC',
    type: 'patient_surge',
    severity: 'warning',
    message: 'Bed occupancy reached 88% with an upward trend in emergency admissions.',
    metric: 'Bed Capacity',
    recommendedAction: 'Discharge stable patients or defer elective observations to West Hill Foothills CHC.',
  },
];

export const INITIAL_TASKS: RedistributionTask[] = [
  {
    id: 'task-1',
    sourceId: 'chc-west',
    sourceName: 'West Hill Foothills CHC',
    targetId: 'phc-north',
    targetName: 'North Valley PHC',
    item: 'Amoxicillin',
    quantity: 300,
    status: 'suggested',
    etaSeconds: 15,
  },
  {
    id: 'task-2',
    sourceId: 'chc-hq',
    sourceName: 'District HQ Hospital & CHC',
    targetId: 'phc-east',
    targetName: 'East Coast Riverside PHC',
    item: 'ORS Packets',
    quantity: 800,
    status: 'suggested',
    etaSeconds: 20,
  },
];
