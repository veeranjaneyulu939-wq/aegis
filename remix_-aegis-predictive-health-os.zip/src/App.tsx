/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  INITIAL_HEALTH_CENTERS,
  INITIAL_ALERTS,
  INITIAL_TASKS,
} from './data';
import { HealthCenter, RedistributionTask, OperationalAlert } from './types';
import MapGrid from './components/MapGrid';
import AICenterAuditor from './components/AICenterAuditor';
import RedistributionPanel from './components/RedistributionPanel';
import MetricsDashboard from './components/MetricsDashboard';
import LoginPage from './components/LoginPage';
import MultiAgentConsole from './components/MultiAgentConsole';
import VoiceAssistant from './components/VoiceAssistant';
import DiseaseTrendTracker from './components/DiseaseTrendTracker';
import TechnicalSpecsConsole from './components/TechnicalSpecsConsole';
import DistrictReportGenerator from './components/DistrictReportGenerator';
import {
  Activity,
  Globe,
  Wifi,
  WifiOff,
  Sparkles,
  Heart,
  Plus,
  ShieldAlert,
  Dna,
  LogOut,
  Layers,
  Brain,
  TrendingUp,
  Code,
} from 'lucide-react';

// Multilingual Dictionary
const TRANSLATIONS: { [key: string]: { [key: string]: string } } = {
  en: {
    title: 'Aegis Health AI',
    subtitle: 'Predictive Public Healthcare Operations Platform',
    mission: 'Resilient and equitable healthcare operations support systems.',
    offlineMode: 'Offline-First Mode Active',
    onlineMode: 'Connected to Cloud AI',
    districtMap: 'District Vector Map',
    redistributionCentre: 'Redistribution Logistics',
    activeAlerts: 'Active Warnings Feed',
    auditPanel: 'Predictive Operations Audit',
    selectedFacility: 'Selected Facility Status',
    balancingSuccess: 'Stock balanced successfully via Aegis logistic corridors.',
    btnLaunch: 'Approve & Launch Drone',
  },
  hi: {
    title: 'एजिस हेल्थ एआई',
    subtitle: 'पूर्वानुमानित सार्वजनिक स्वास्थ्य संचालन मंच',
    mission: 'लचीला और न्यायसंगत स्वास्थ्य सेवा संचालन सहायता प्रणाली।',
    offlineMode: 'ऑफ़लाइन-फ़र्स्ट मोड सक्रिय',
    onlineMode: 'क्लाउड एआई से जुड़े हैं',
    districtMap: 'जिला वेक्टर मानचित्र',
    redistributionCentre: 'पुनर्वितरण रसद केंद्र',
    activeAlerts: 'सक्रिय चेतावनी फ़ीड',
    auditPanel: 'पूर्वानుమానిత संचालन लेखापरीक्षा',
    selectedFacility: 'चयनित केंद्र की स्थिति',
    balancingSuccess: 'एजिस रसद गलियारों के माध्यम से स्टॉक संतुलित किया गया।',
    btnLaunch: 'अनुमोदन करें और ड्रोन लॉन्च करें',
  },
  te: {
    title: 'ఏజిస్ హెల్త్ AI',
    subtitle: 'ప్రిడిక్టివ్ పబ్లిక్ హెల్త్‌కేర్ ఆపరేషన్స్ ప్లాట్‌ఫారమ్',
    mission: 'సుస్థిరమైన మరియు సమానమైన ఆరోగ్య సంరక్షణ నిర్వహణ సహాయ వ్యవస్థ.',
    offlineMode: 'ఆఫ్‌లైన్-ఫస్ట్ మోడ్ యాక్టివ్‌లో ఉంది',
    onlineMode: 'క్లౌడ్ AI కి కనెక్ట్ చేయబడింది',
    districtMap: 'జిల్లా వెక్టర్ మ్యాప్',
    redistributionCentre: 'స్టాక్ పునఃపంపిణీ లాజిస్టిక్స్',
    activeAlerts: 'యాక్టివ్ హెచ్చరికల ఫీడ్',
    auditPanel: 'ప్రిడిక్టివ్ ఆపరేషన్స్ ఆడిట్',
    selectedFacility: 'ఎంచుకున్న క్లినిక్ స్థితి',
    balancingSuccess: 'ఏజిస్ లాజిస్టిక్ మార్గాల ద్వారా స్టాక్ విజయవంతంగా బ్యాలెన్స్ చేయబడింది.',
    btnLaunch: 'ఆమోదించి డ్రోన్ ప్రారంభించండి',
  },
  ta: {
    title: 'ஏஜிஸ் ஹெல்த் AI',
    subtitle: 'முன்கணிப்பு பொது சுகாதார செயல்பாட்டு தளம்',
    mission: 'நெகிழ்ச்சியான மற்றும் சமமான சுகாதார செயல்பாட்டு ஆதரவு அமைப்புகள்.',
    offlineMode: 'ஆஃப்லைன்-முதல் பயன்முறை செயலில் உள்ளது',
    onlineMode: 'கிளவுட் AI உடன் இணைக்கப்பட்டுள்ளது',
    districtMap: 'மாவட்ட திசையன் வரைபடம்',
    redistributionCentre: 'பகிர்ந்தளிப்பு தளவாடங்கள்',
    activeAlerts: 'செயலில் உள்ள எச்சரிக்கை ஊட்டம்',
    auditPanel: 'செயல்பாட்டு தணிக்கை',
    selectedFacility: 'தேர்ந்தெடுக்கப்பட்ட மைய நிலை',
    balancingSuccess: 'ஏஜிஸ் தளவாடங்கள் மூலம் இருப்பு வெற்றிகரமாக சமப்படுத்தப்பட்டது.',
    btnLaunch: 'ஒப்புதல் மற்றும் ட்ரோன் துவக்கம்',
  },
};

export default function App() {
  const [lang, setLang] = useState('en');
  const [isOnline, setIsOnline] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [activeDashboardMode, setActiveDashboardMode] = useState<'twin' | 'multiagent' | 'forecast' | 'specs'>('twin');

  // Core Simulation States
  const [healthCenters, setHealthCenters] = useState<HealthCenter[]>(INITIAL_HEALTH_CENTERS);
  const [alerts, setAlerts] = useState<OperationalAlert[]>(INITIAL_ALERTS);
  const [tasks, setTasks] = useState<RedistributionTask[]>(INITIAL_TASKS);
  const [selectedCenterId, setSelectedCenterId] = useState<string>('phc-north');

  // AI District-Wide Optimization State
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationSummary, setOptimizationSummary] = useState('');

  // Local notification banner
  const [notification, setNotification] = useState<string | null>(null);

  // Active Center Object
  const selectedCenter = healthCenters.find(c => c.id === selectedCenterId) || healthCenters[0];

  const t = (key: string) => {
    return TRANSLATIONS[lang]?.[key] || TRANSLATIONS['en'][key];
  };

  // Synchronize initial dataset from Express / Firestore backend on Mount
  useEffect(() => {
    const loadBackendData = async () => {
      try {
        const [centersRes, alertsRes, tasksRes] = await Promise.all([
          fetch('/api/centers'),
          fetch('/api/alerts'),
          fetch('/api/tasks')
        ]);
        
        if (centersRes.ok && alertsRes.ok && tasksRes.ok) {
          const loadedCenters = await centersRes.json();
          const loadedAlerts = await alertsRes.json();
          const loadedTasks = await tasksRes.json();
          
          if (loadedCenters && loadedCenters.length > 0) setHealthCenters(loadedCenters);
          if (loadedAlerts) setAlerts(loadedAlerts);
          if (loadedTasks) setTasks(loadedTasks);
          console.log('[Aegis Frontend] Initialized full-stack data states from cloud database successfully.');
        }
      } catch (error) {
        console.warn('[Aegis Frontend] Operating in offline-fallback sandbox context:', error);
      }
    };
    
    loadBackendData();
    
    // Lazy load Client-side Firebase configuration
    import('./lib/firebase').then(({ initFirebase }) => {
      initFirebase().then(fb => {
        if (fb) {
          console.log('[Aegis Frontend] Client-side Firebase secure Auth module ready.');
        }
      });
    }).catch(err => console.error('Failed to import client Firebase:', err));
  }, []);

  // Logistics Countdown Timer Loop
  useEffect(() => {
    const interval = setInterval(() => {
      setTasks(prevTasks => {
        let stateChanged = false;
        const updated = prevTasks.map(task => {
          if (task.status === 'transit') {
            if (task.etaSeconds > 1) {
              return { ...task, etaSeconds: task.etaSeconds - 1 };
            } else {
              // Mark completed, trigger stock adjustment
              stateChanged = true;
              triggerStockTransfer(task.sourceId, task.targetId, task.item, task.quantity);
              
              const completedTask: RedistributionTask = { ...task, status: 'completed', etaSeconds: 0 };
              // Sync updated completed task state to backend
              fetch('/api/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(completedTask)
              }).catch(err => console.error('Task status sync error:', err));

              return completedTask;
            }
          }
          return task;
        });

        if (stateChanged) {
          // Clear standard mock shortage alert for target center if applicable
          setTimeout(() => {
            setNotification(t('balancingSuccess'));
          }, 200);
        }

        return updated;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [lang, healthCenters]);

  // Execute Stock Transfer (Deduct from source, Add to target)
  const triggerStockTransfer = (sourceId: string, targetId: string, item: string, quantity: number) => {
    let sourceUpdate: HealthCenter | null = null;
    let targetUpdate: HealthCenter | null = null;

    setHealthCenters(prevCenters => {
      const next = prevCenters.map(center => {
        if (center.id === sourceId) {
          const invItem = center.inventory[item];
          if (invItem) {
            const newStock = Math.max(invItem.stock - quantity, 0);
            sourceUpdate = {
              ...center,
              inventory: {
                ...center.inventory,
                [item]: {
                  ...invItem,
                  stock: newStock,
                  status: newStock < invItem.minRequired ? 'warning' : 'optimal',
                },
              },
            };
            return sourceUpdate;
          }
        }
        if (center.id === targetId) {
          const invItem = center.inventory[item];
          if (invItem) {
            const newStock = invItem.stock + quantity;
            targetUpdate = {
              ...center,
              inventory: {
                ...center.inventory,
                [item]: {
                  ...invItem,
                  stock: newStock,
                  status: 'optimal',
                  depletionDays: Math.min(invItem.depletionDays + 15, 30), // Extend depletion window
                },
              },
            };
            return targetUpdate;
          }
        }
        return center;
      });

      // Sync modifications to backend
      if (sourceUpdate) {
        fetch('/api/centers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(sourceUpdate)
        }).catch(err => console.error('Failed to sync source inventory update:', err));
      }
      if (targetUpdate) {
        fetch('/api/centers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(targetUpdate)
        }).catch(err => console.error('Failed to sync target inventory update:', err));
      }

      return next;
    });

    // Clear alert related to targetId and item
    setAlerts(prevAlerts => {
      const targetAlert = prevAlerts.find(alert => alert.centerId === targetId && alert.type === 'shortage' && alert.message.includes(item));
      if (targetAlert) {
        fetch(`/api/alerts/${targetAlert.id}`, { method: 'DELETE' }).catch(err => console.error('Failed to sync alert delete:', err));
      }
      return prevAlerts.filter(alert => {
        const isTargetShortage = alert.centerId === targetId && alert.type === 'shortage' && alert.message.includes(item);
        return !isTargetShortage;
      });
    });
  };

  // Launch a suggested redistribution task
  const executeRedistributionTask = (taskId: string) => {
    setTasks(prevTasks => {
      return prevTasks.map(task => {
        if (task.id === taskId) {
          const updated = { ...task, status: 'transit' as const, etaSeconds: 12 };
          // Sync start of transit with backend
          fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updated)
          }).catch(err => console.error('Failed to sync task transit status:', err));
          return updated;
        }
        return task;
      });
    });
  };

  // Trigger district-wide optimization (Gemini route)
  const requestAIOptimization = async () => {
    setIsOptimizing(true);
    setOptimizationSummary('');

    try {
      if (!isOnline) {
        // Local simulation fallback for offline mode
        setTimeout(() => {
          setOptimizationSummary('Offline balancing algorithm executed. Calculated drone routes between District HQ and East Coast Riverside to resolve medicine depletion vectors immediately.');
          setIsOptimizing(false);
        }, 1500);
        return;
      }

      const response = await fetch('/api/gemini/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ healthCenters, activeAlerts: alerts }),
      });

      if (!response.ok) {
        throw new Error('Optimization request failed');
      }

      const data = await response.json();
      setOptimizationSummary(data.strategicSummary || 'District operations audit complete. Suggested optimized pathways below.');
      
      // Merge suggested transfers from Gemini into our task state
      if (data.proposedTransfers && data.proposedTransfers.length > 0) {
        const newTasks: RedistributionTask[] = data.proposedTransfers.map((t: any, index: number) => ({
          id: `ai-task-${Date.now()}-${index}`,
          sourceId: t.sourceId,
          sourceName: t.sourceName,
          targetId: t.targetId,
          targetName: t.targetName,
          item: t.item,
          quantity: t.quantity,
          status: 'suggested',
          etaSeconds: 15,
        }));

        // Persist newly generated tasks to database
        newTasks.forEach(task => {
          fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(task)
          }).catch(err => console.error('Failed to sync AI proposed task:', err));
        });

        setTasks(prev => [...newTasks, ...prev.filter(pt => pt.status !== 'suggested')]);
      }
    } catch (err) {
      console.error(err);
      setOptimizationSummary('Automated heuristics balance completed. Standard redistribution profiles loaded. Ensure GEMINI_API_KEY is configured in your secrets tab for absolute AI logistics optimizations.');
      // Local fallbacks
      const fallbackTasks: RedistributionTask[] = [
        {
          id: `fallback-task-${Date.now()}`,
          sourceId: 'chc-west',
          sourceName: 'West Hill Foothills CHC',
          targetId: 'phc-north',
          targetName: 'North Valley PHC',
          item: 'Amoxicillin',
          quantity: 250,
          status: 'suggested',
          etaSeconds: 15,
        }
      ];
      setTasks(prev => [...fallbackTasks, ...prev.filter(pt => pt.status !== 'suggested')]);
    } finally {
      setIsOptimizing(false);
    }
  };

  // Synchronize health center updates with Cloud Firestore
  const updateHealthCenter = async (updatedCenter: HealthCenter) => {
    setHealthCenters(prev => prev.map(c => c.id === updatedCenter.id ? updatedCenter : c));
    try {
      const response = await fetch('/api/centers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedCenter)
      });
      if (response.ok) {
        setNotification(`Stored clinical data for ${updatedCenter.name} to Firestore successfully.`);
      } else {
        throw new Error('Database server error.');
      }
    } catch (err) {
      console.error(err);
      setNotification('Operational data updated locally.');
    }
  };

  // Create new clinical node facility and store in Cloud Firestore
  const addHealthCenter = async (newCenter: HealthCenter) => {
    setHealthCenters(prev => [...prev, newCenter]);
    try {
      const response = await fetch('/api/centers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCenter)
      });
      if (response.ok) {
        setNotification(`Stored new facility ${newCenter.name} to Firestore successfully.`);
      } else {
        throw new Error('Database server error.');
      }
    } catch (err) {
      console.error(err);
      setNotification('Facility added locally.');
    }
  };

  // Reset Cloud database schemas to default baseline values
  const resetDatabaseToDefault = async () => {
    try {
      const response = await fetch('/api/reset', {
        method: 'POST'
      });
      if (response.ok) {
        const [centersRes, alertsRes, tasksRes] = await Promise.all([
          fetch('/api/centers'),
          fetch('/api/alerts'),
          fetch('/api/tasks')
        ]);
        if (centersRes.ok && alertsRes.ok && tasksRes.ok) {
          setHealthCenters(await centersRes.json());
          setAlerts(await alertsRes.json());
          setTasks(await tasksRes.json());
          setNotification('Successfully restored database state to clinical blueprints.');
        }
      }
    } catch (err) {
      console.error('Database reset failed:', err);
      setNotification('Failed to execute database reset.');
    }
  };

  if (!isLoggedIn) {
    return (
      <LoginPage
        onLogin={(role) => {
          setIsLoggedIn(true);
          setUserRole(role);
        }}
        lang={lang}
        setLang={setLang}
      />
    );
  }

  return (
    <div id="aegis-root" className="min-h-screen bg-slate-100 p-4 text-slate-800 dark:bg-slate-950 dark:text-slate-100 sm:p-6 md:p-8 selection:bg-indigo-500 selection:text-white">
      
      {/* Top Banner & Translation layers */}
      <div className="mx-auto max-w-7xl">
        <header className="mb-8 flex flex-col justify-between gap-6 border-b border-slate-200/60 pb-6 dark:border-slate-800/60 md:flex-row md:items-center">
          
          {/* Logo & Slogan */}
          <div className="flex items-start gap-3.5">
            <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 to-cyan-500 shadow-md">
              <Dna className="h-6 w-6 text-white animate-pulse" />
              <div className="absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full border-2 border-slate-100 bg-emerald-500 dark:border-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-sans text-2xl font-black tracking-tight text-slate-900 dark:text-white">
                  {t('title')}
                </h1>
                <span className="rounded-md bg-indigo-500/10 px-2 py-0.5 font-mono text-[9px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest">
                  v3.5 Live
                </span>
              </div>
              <p className="font-sans text-xs font-semibold text-slate-500 dark:text-slate-400">
                {t('subtitle')}
              </p>
            </div>
          </div>

          {/* Real-time configuration toggles */}
          <div className="flex flex-wrap items-center gap-4">
            
            {/* Language Dictionary Selector */}
            <div className="flex items-center gap-1 rounded-xl bg-white border border-slate-200 p-1 dark:bg-slate-900 dark:border-slate-800 shadow-xs">
              <Globe className="h-4 w-4 text-slate-400 mx-1" />
              {['en', 'hi', 'te', 'ta'].map(l => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`rounded-lg px-2.5 py-1 text-xs font-bold transition-all ${
                    lang === l
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  {l.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Online/Offline Toggle */}
            <button
              onClick={() => setIsOnline(!isOnline)}
              className={`flex items-center gap-2 rounded-xl border px-3.5 py-1.5 font-sans text-xs font-bold shadow-xs transition-all ${
                isOnline
                  ? 'border-emerald-500/20 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400'
                  : 'border-amber-500/20 bg-amber-500/5 text-amber-600 dark:text-amber-400'
              }`}
            >
              {isOnline ? (
                <>
                  <Wifi className="h-3.5 w-3.5" />
                  <span>{t('onlineMode')}</span>
                </>
              ) : (
                <>
                  <WifiOff className="h-3.5 w-3.5" />
                  <span>{t('offlineMode')}</span>
                </>
              )}
            </button>

            {/* Secure Sign Out button */}
            <button
              onClick={() => {
                setIsLoggedIn(false);
                setUserRole(null);
              }}
              className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-1.5 text-xs font-bold shadow-xs transition-all hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800/80"
            >
              <LogOut className="h-3.5 w-3.5 text-rose-500" />
              <span>Sign Out</span>
            </button>
          </div>
        </header>

        {/* Local notification Alert bar */}
        <AnimatePresence>
          {notification && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-6 flex items-center justify-between rounded-xl border border-emerald-500/20 bg-emerald-500/10 px-4 py-3.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400"
            >
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
                <span>{notification}</span>
              </div>
              <button
                onClick={() => setNotification(null)}
                className="font-mono text-xs opacity-70 hover:opacity-100"
              >
                Dismiss
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mission Statement Callout */}
        <div className="mb-8 rounded-2xl bg-gradient-to-r from-indigo-900 via-slate-900 to-cyan-950 p-6 text-white shadow-md">
          <div className="flex items-start gap-4">
            <div className="rounded-lg bg-indigo-500/20 p-2.5">
              <Activity className="h-6 w-6 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <span className="font-mono text-[9px] font-black tracking-widest text-cyan-400 uppercase">
                AEGIS HEALTH MISSION • ACCESS ROLE: {userRole?.toUpperCase()}
              </span>
              <p className="mt-1 font-sans text-sm md:text-base font-semibold leading-relaxed text-slate-100">
                {t('mission')} Empowering Primary and Community Health Centres (PHCs/CHCs) with predictive, real-time AI modeling to eliminate medicine stockouts, distribute critical physicians, and optimize bed logistics.
              </p>
            </div>
          </div>
        </div>

        {/* Dynamic OS Tab Bar Controls */}
        <div className="mb-6 flex flex-wrap gap-2 rounded-2xl bg-white border border-slate-200/80 p-1.5 dark:bg-slate-900 dark:border-slate-800 shadow-xs">
          <button
            onClick={() => setActiveDashboardMode('twin')}
            className={`flex items-center gap-2 rounded-xl px-4 py-3 text-xs font-bold transition-all ${
              activeDashboardMode === 'twin'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-950/40'
            }`}
          >
            <Layers className="h-4 w-4" />
            <span>Clinical Digital Twin Map</span>
          </button>
          
          <button
            onClick={() => setActiveDashboardMode('multiagent')}
            className={`flex items-center gap-2 rounded-xl px-4 py-3 text-xs font-bold transition-all ${
              activeDashboardMode === 'multiagent'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-950/40'
            }`}
          >
            <Brain className="h-4 w-4" />
            <span>Multi-Agent AI Simulation</span>
          </button>

          <button
            onClick={() => setActiveDashboardMode('forecast')}
            className={`flex items-center gap-2 rounded-xl px-4 py-3 text-xs font-bold transition-all ${
              activeDashboardMode === 'forecast'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-950/40'
            }`}
          >
            <TrendingUp className="h-4 w-4" />
            <span>Outbreak Projections & Audits</span>
          </button>

          <button
            onClick={() => setActiveDashboardMode('specs')}
            className={`flex items-center gap-2 rounded-xl px-4 py-3 text-xs font-bold transition-all ${
              activeDashboardMode === 'specs'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-950/40'
            }`}
          >
            <Code className="h-4 w-4" />
            <span>System Blueprints & Specs</span>
          </button>
        </div>

        {/* Main Workspace Layout Renderers */}
        <AnimatePresence mode="wait">
          {activeDashboardMode === 'twin' && (
            <motion.main
              key="twin"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="grid gap-6 lg:grid-cols-12"
            >
              {/* Left Column: Map & Redistribution Panel (7 cols) */}
              <div className="flex flex-col gap-6 lg:col-span-7">
                {/* Map Component */}
                <MapGrid
                  centers={healthCenters}
                  selectedCenterId={selectedCenterId}
                  onSelectCenter={setSelectedCenterId}
                  activeTasks={tasks}
                />

                {/* Smart stock Redistribution Panel */}
                <RedistributionPanel
                  tasks={tasks}
                  centers={healthCenters}
                  isOnline={isOnline}
                  onExecuteTask={executeRedistributionTask}
                  onRequestAIOptimization={requestAIOptimization}
                  isOptimizing={isOptimizing}
                  optimizationSummary={optimizationSummary}
                />
              </div>

              {/* Right Column: Predictive Auditor & Analytics Metrics (5 cols) */}
              <div className="flex flex-col gap-6 lg:col-span-5">
                {/* Predictive Auditor */}
                <AICenterAuditor
                  center={selectedCenter}
                  districtAlerts={alerts}
                  isOnline={isOnline}
                />

                {/* High-fidelity Statistics & Metrics dashboard */}
                <MetricsDashboard
                  centers={healthCenters}
                  alerts={alerts}
                  selectedCenterId={selectedCenterId}
                  onSelectCenter={setSelectedCenterId}
                  onUpdateCenter={updateHealthCenter}
                  onAddCenter={addHealthCenter}
                  onResetDatabase={resetDatabaseToDefault}
                />
              </div>
            </motion.main>
          )}

          {activeDashboardMode === 'multiagent' && (
            <motion.main
              key="multiagent"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="grid gap-6 md:grid-cols-12"
            >
              <div className="md:col-span-8 flex flex-col gap-6">
                <MultiAgentConsole
                  centers={healthCenters}
                  onGenerateAction={(agent, recommendation) => {
                    setNotification(`Deployed Strategy for ${agent}: ${recommendation}`);
                  }}
                />
              </div>
              <div className="md:col-span-4 flex flex-col gap-6">
                <VoiceAssistant
                  lang={lang}
                  onVoiceCommand={(command) => {
                    setNotification(`Transmitting Voice Instruction: "${command}"`);
                  }}
                />
              </div>
            </motion.main>
          )}

          {activeDashboardMode === 'forecast' && (
            <motion.main
              key="forecast"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="grid gap-6 md:grid-cols-12"
            >
              <div className="md:col-span-7 flex flex-col gap-6">
                <DiseaseTrendTracker />
              </div>
              <div className="md:col-span-5 flex flex-col gap-6">
                <DistrictReportGenerator centers={healthCenters} />
              </div>
            </motion.main>
          )}

          {activeDashboardMode === 'specs' && (
            <motion.main
              key="specs"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="grid gap-6"
            >
              <TechnicalSpecsConsole />
            </motion.main>
          )}
        </AnimatePresence>

        {/* High-fidelity visual footer */}
        <footer className="mt-12 border-t border-slate-200/60 pt-6 text-center dark:border-slate-800/60">
          <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest">
            Antigravity Intelligent Systems © 2026 • Connected Clinical Mesh Network
          </p>
        </footer>
      </div>
    </div>
  );
}
