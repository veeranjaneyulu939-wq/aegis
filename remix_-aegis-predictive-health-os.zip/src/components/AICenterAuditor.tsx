/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HealthCenter, OperationalAlert } from '../types';
import { Sparkles, Brain, AlertTriangle, CheckCircle, RefreshCw, Activity, Calendar, ShieldCheck, Microscope } from 'lucide-react';

interface AICenterAuditorProps {
  center: HealthCenter;
  districtAlerts: OperationalAlert[];
  isOnline: boolean;
}

interface AuditResult {
  riskLevel: 'low' | 'medium' | 'high';
  prediction: string;
  criticalShortages: string[];
  redistributionStrategy: string;
  labStaffingContingency: string;
  actionItems: string[];
}

export default function AICenterAuditor({ center, districtAlerts, isOnline }: AICenterAuditorProps) {
  const [loading, setLoading] = useState(false);
  const [audit, setAudit] = useState<AuditResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Status updates during generation
  const [statusText, setStatusText] = useState('Initializing Antigravity Operations AI...');

  const generateAudit = async () => {
    setLoading(true);
    setError(null);
    setAudit(null);

    const phases = [
      'Ingesting clinical patient flow curves...',
      'Calculating medicine inventory depletion rates...',
      'Mapping nearest Community Health Centre supply corridors...',
      'Synthesizing predictive staffing forecasts...',
      'Generating Antigravity AI Action Framework...',
    ];

    let phaseIndex = 0;
    const interval = setInterval(() => {
      if (phaseIndex < phases.length - 1) {
        phaseIndex++;
        setStatusText(phases[phaseIndex]);
      }
    }, 1200);

    try {
      const response = await fetch('/api/gemini/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ center, districtAlerts }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate audit.');
      }

      const data = await response.json();
      setAudit(data);
    } catch (err: any) {
      console.error(err);
      setError('Could not connect to Gemini. Falling back to local clinical model.');
      // Local fallback representation
      setAudit({
        riskLevel: center.bedOccupancy > 80 ? 'high' : 'medium',
        prediction: `Patient flow is ${center.patientFlowTrend} at ${center.patientFlow} patients per day, suggesting bed pressure of ${center.bedOccupancy}% will stay steady or increase over the next 14 days.`,
        criticalShortages: Object.values(center.inventory)
          .filter(i => i.status === 'critical')
          .map(i => i.name),
        redistributionStrategy: `Local logistics rules recommend transferring shortfalls of critical drugs directly from nearest CHC storage buffers.`,
        labStaffingContingency: center.labServicesActive 
          ? 'Diagnostics online. Keep backup reagent lists validated.' 
          : 'Clinical laboratory is reported offline. Route urgent blood chemistry panels to District HQ immediately.',
        actionItems: [
          'Verify refrigeration metrics for temperature-sensitive antigens [Immediate]',
          'Adjust staff rotation rosters to compensate for patient influx [24-hours]',
          'Schedule preventative maintenance check for laboratory diagnostics [Next 3 days]'
        ],
      });
    } finally {
      clearInterval(interval);
      setLoading(false);
    }
  };

  const getRiskColor = (level?: 'low' | 'medium' | 'high') => {
    if (level === 'high') return 'bg-rose-500/10 text-rose-500 border-rose-500/20';
    if (level === 'medium') return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
    return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
  };

  return (
    <div id="ai-auditor-container" className="flex flex-col gap-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div>
        <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
          <Brain className="h-5 w-5 text-indigo-500" />
          Antigravity Predictive Operations Auditor
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Leverage real-time hospital parameters to extract actionable logistics forecasts
        </p>
      </div>

      {/* Selected Facility Overview */}
      <div className="grid grid-cols-2 gap-4 rounded-xl border border-slate-100 bg-slate-50/50 p-4 dark:border-slate-800 dark:bg-slate-950/30 md:grid-cols-4">
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-400 dark:text-slate-500">Name</div>
          <div className="font-sans text-sm font-semibold text-slate-700 dark:text-slate-200">{center.name}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-400 dark:text-slate-500">Type</div>
          <div className="font-mono text-xs font-semibold text-slate-600 dark:text-slate-300">{center.type === 'CHC' ? 'Community Health Centre' : 'Primary Health Centre'}</div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-400 dark:text-slate-500">Patient Inflow</div>
          <div className="flex items-center gap-1 font-mono text-xs font-bold text-slate-700 dark:text-slate-200">
            {center.patientFlow} / day
            <span className={center.patientFlowTrend === 'rising' ? 'text-rose-500' : center.patientFlowTrend === 'falling' ? 'text-emerald-500' : 'text-slate-400'}>
              {center.patientFlowTrend === 'rising' ? '↑' : center.patientFlowTrend === 'falling' ? '↓' : '→'}
            </span>
          </div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-wider text-slate-400 dark:text-slate-500">Lab Diagnostics</div>
          <div className={`flex items-center gap-1 font-mono text-xs font-semibold ${center.labServicesActive ? 'text-emerald-500' : 'text-rose-500 animate-pulse'}`}>
            <Microscope className="h-3 w-3" />
            {center.labServicesActive ? 'ONLINE' : 'OUTAGE'}
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="flex flex-col gap-3">
        {!isOnline && (
          <div className="flex items-center gap-2 rounded-lg border border-amber-500/20 bg-amber-500/10 px-3 py-2 text-xs text-amber-500">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>Platform is in <strong>Offline Mode</strong>. Local analytical engines will generate a static simulation audit.</span>
          </div>
        )}
        <button
          onClick={generateAudit}
          disabled={loading}
          className="relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 py-3 text-sm font-semibold text-white shadow-md transition-all hover:from-indigo-500 hover:to-indigo-600 active:scale-98 disabled:opacity-80"
        >
          {loading ? (
            <RefreshCw className="h-4 w-4 animate-spin text-white" />
          ) : (
            <Sparkles className="h-4 w-4 text-amber-300" />
          )}
          {loading ? 'Synthesizing AI Audit...' : 'Execute Antigravity AI Predictive Audit'}
        </button>
      </div>

      {/* Displaying loading states or results */}
      <AnimatePresence mode="wait">
        {loading && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col items-center justify-center gap-4 rounded-xl border border-indigo-100 bg-indigo-50/20 p-8 dark:border-indigo-950 dark:bg-indigo-950/20"
          >
            <div className="relative">
              <span className="absolute inline-flex h-12 w-12 animate-ping rounded-full bg-indigo-500 opacity-20" />
              <div className="relative flex h-12 w-12 items-center justify-center rounded-full bg-indigo-600 text-white">
                <Brain className="h-6 w-6 animate-pulse" />
              </div>
            </div>
            <div className="text-center">
              <div className="font-sans text-sm font-semibold text-slate-800 dark:text-slate-100">{statusText}</div>
              <p className="font-mono text-xs text-indigo-500 dark:text-indigo-400 mt-1">
                Gemini 3.5 Flash modeling active
              </p>
            </div>
          </motion.div>
        )}

        {audit && !loading && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col gap-6 rounded-xl border border-slate-200 bg-slate-50/50 p-5 dark:border-slate-800 dark:bg-slate-950/20"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <span className="font-mono text-xs font-semibold text-slate-500 dark:text-slate-400">
                AUDIT METRIC: {center.name.toUpperCase()}
              </span>
              <span className={`rounded-full border px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider ${getRiskColor(audit.riskLevel)}`}>
                Risk Level: {audit.riskLevel}
              </span>
            </div>

            {/* Prediction section */}
            <div className="flex gap-3">
              <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-indigo-500/10 text-indigo-500 dark:bg-indigo-500/20">
                <Activity className="h-3.5 w-3.5" />
              </div>
              <div>
                <h4 className="font-sans text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">14-Day Predictive Outlook</h4>
                <p className="mt-1 font-sans text-sm text-slate-600 dark:text-slate-300">{audit.prediction}</p>
              </div>
            </div>

            {/* Smart redistribution Strategy */}
            <div className="flex gap-3">
              <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-cyan-500/10 text-cyan-500 dark:bg-cyan-500/20">
                <RefreshCw className="h-3.5 w-3.5" />
              </div>
              <div>
                <h4 className="font-sans text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">Logistical Balancing Strategy</h4>
                <p className="mt-1 font-sans text-sm text-slate-600 dark:text-slate-300">{audit.redistributionStrategy}</p>
              </div>
            </div>

            {/* Laboratory or Outage strategy */}
            <div className="flex gap-3">
              <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-500/10 text-amber-500 dark:bg-amber-500/20">
                <AlertTriangle className="h-3.5 w-3.5" />
              </div>
              <div>
                <h4 className="font-sans text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">Diagnostic & Lab Contingency</h4>
                <p className="mt-1 font-sans text-sm text-slate-600 dark:text-slate-300">{audit.labStaffingContingency}</p>
              </div>
            </div>

            {/* Action Item list */}
            <div>
              <h4 className="mb-3 flex items-center gap-1.5 font-sans text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                <ShieldCheck className="h-4 w-4 text-emerald-500" />
                Antigravity Corrective Action Protocol
              </h4>
              <div className="grid gap-2.5">
                {audit.actionItems.map((item, index) => (
                  <div key={index} className="flex items-start gap-2.5 rounded-lg border border-slate-100 bg-white p-3 shadow-sm dark:border-slate-800 dark:bg-slate-900/80">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-emerald-500 shrink-0" />
                    <span className="font-sans text-xs text-slate-600 dark:text-slate-300">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
