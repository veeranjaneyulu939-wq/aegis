/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HealthCenter, RedistributionTask } from '../types';
import { Shield, Plus, AlertTriangle, Truck, Compass } from 'lucide-react';

interface MapGridProps {
  centers: HealthCenter[];
  selectedCenterId: string;
  onSelectCenter: (id: string) => void;
  activeTasks: RedistributionTask[];
}

export default function MapGrid({ centers, selectedCenterId, onSelectCenter, activeTasks }: MapGridProps) {
  // Find transit tasks to draw paths
  const transitTasks = activeTasks.filter(t => t.status === 'transit');

  // Helper to find location coordinates of a center by ID
  const getCenterCoords = (id: string) => {
    const c = centers.find(center => center.id === id);
    return c ? c.location : { x: 50, y: 50 };
  };

  // Helper to determine color status based on inventory levels
  const getCenterStatusColor = (center: HealthCenter) => {
    const items = Object.values(center.inventory);
    const hasCritical = items.some(i => i.status === 'critical');
    const hasWarning = items.some(i => i.status === 'warning');
    if (hasCritical) return 'border-rose-500 bg-rose-500/20 text-rose-500 text-rose-400';
    if (hasWarning) return 'border-amber-500 bg-amber-500/20 text-amber-500 text-amber-400';
    return 'border-emerald-500 bg-emerald-500/20 text-emerald-500 text-emerald-400';
  };

  return (
    <div id="map-grid-container" className="relative w-full overflow-hidden rounded-2xl border border-slate-200 bg-slate-50 p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
            <Compass className="h-5 w-5 text-indigo-500" />
            District Vector Operations Grid
          </h3>
          <p className="font-mono text-xs text-slate-500 dark:text-slate-400">
            Real-time coordinates & vector logistic routing
          </p>
        </div>
        <div className="flex gap-4 font-mono text-xs">
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-emerald-500" /> Optimal
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-amber-500" /> Warning
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-rose-500" /> Critical
          </span>
        </div>
      </div>

      {/* Interactive SVG Map */}
      <div className="relative aspect-[4/3] w-full rounded-xl bg-slate-100 p-4 border border-slate-200 dark:bg-slate-950 dark:border-slate-800">
        {/* Radar grids */}
        <div className="absolute inset-0 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] dark:bg-[radial-gradient(#334155_1px,transparent_1px)] [background-size:24px_24px] opacity-60" />

        <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full select-none">
          {/* Active Logistics Paths */}
          {transitTasks.map(task => {
            const start = getCenterCoords(task.sourceId);
            const end = getCenterCoords(task.targetId);
            return (
              <g key={task.id}>
                {/* Dashed background path */}
                <line
                  x1={start.x}
                  y1={start.y}
                  x2={end.x}
                  y2={end.y}
                  stroke="#6366f1"
                  strokeWidth="0.8"
                  strokeDasharray="2, 2"
                  className="opacity-70"
                />
                {/* Pulsing delivery trail */}
                <line
                  x1={start.x}
                  y1={start.y}
                  x2={end.x}
                  y2={end.y}
                  stroke="#38bdf8"
                  strokeWidth="1.2"
                  strokeDasharray="4 20"
                  strokeDashoffset="100"
                  className="animate-[dash_10s_linear_infinite]"
                />
                {/* Active Antigravity Logistics Drone */}
                <motion.circle
                  r="1.5"
                  fill="#06b6d4"
                  stroke="#ffffff"
                  strokeWidth="0.4"
                  style={{ shadow: '0 0 8px #06b6d4' }}
                  initial={{ cx: start.x, cy: start.y }}
                  animate={{ cx: end.x, cy: end.y }}
                  transition={{
                    duration: 5,
                    ease: 'linear',
                    repeat: Infinity,
                  }}
                />
                {/* Active Transport Pulse label */}
                <motion.g
                  initial={{ x: start.x, y: start.y - 3 }}
                  animate={{ x: end.x, y: end.y - 3 }}
                  transition={{
                    duration: 5,
                    ease: 'linear',
                    repeat: Infinity,
                  }}
                >
                  <rect
                    x="-6"
                    y="-3"
                    width="12"
                    height="4"
                    rx="1"
                    fill="#0f172a"
                    stroke="#06b6d4"
                    strokeWidth="0.2"
                    className="opacity-90"
                  />
                  <text
                    fontSize="1.5"
                    fill="#38bdf8"
                    fontFamily="monospace"
                    textAnchor="middle"
                    y="-0.4"
                  >
                    DRONE IN TRANSIT
                  </text>
                </motion.g>
              </g>
            );
          })}

          {/* Links between District CHCs & Satellites (Hub & Spoke view) */}
          {centers
            .filter(c => c.type === 'PHC')
            .map(phc => {
              // Find the closest CHC as its structural hub
              const chcs = centers.filter(c => c.type === 'CHC');
              let nearestChc = chcs[0];
              let minDist = Infinity;
              chcs.forEach(chc => {
                const dist = Math.hypot(chc.location.x - phc.location.x, chc.location.y - phc.location.y);
                if (dist < minDist) {
                  minDist = dist;
                  nearestChc = chc;
                }
              });

              return (
                <line
                  key={`link-${phc.id}`}
                  x1={phc.location.x}
                  y1={phc.location.y}
                  x2={nearestChc.location.x}
                  y2={nearestChc.location.y}
                  stroke="#94a3b8"
                  strokeWidth="0.25"
                  className="opacity-30 dark:opacity-20"
                />
              );
            })}
        </svg>

        {/* Floating Health Center Interactive Nodes */}
        {centers.map(center => {
          const isSelected = center.id === selectedCenterId;
          const statusColors = getCenterStatusColor(center);
          const hasShortage = Object.values(center.inventory).some(i => i.status === 'critical');

          return (
            <motion.button
              key={center.id}
              onClick={() => onSelectCenter(center.id)}
              className={`absolute flex flex-col items-center justify-center`}
              style={{
                left: `${center.location.x}%`,
                top: `${center.location.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              whileHover={{ scale: 1.15 }}
              whileTap={{ scale: 0.95 }}
            >
              {/* Outer pulsing ring for critical statuses */}
              {hasShortage && (
                <span className="absolute inline-flex h-10 w-10 animate-ping rounded-full bg-rose-400 opacity-20" />
              )}

              {/* Central Node Visual */}
              <div
                className={`relative flex h-8 w-8 items-center justify-center rounded-xl border-2 shadow-md transition-all ${
                  isSelected
                    ? 'scale-110 ring-4 ring-indigo-500/30 ring-offset-2 dark:ring-offset-slate-950 bg-slate-900 border-indigo-500 text-white'
                    : `bg-white dark:bg-slate-900 ${statusColors}`
                }`}
              >
                {center.type === 'CHC' ? (
                  <Shield className="h-4 w-4" />
                ) : (
                  <Plus className="h-4 w-4" />
                )}

                {/* Micro alert marker */}
                {hasShortage && (
                  <span className="absolute -top-1.5 -right-1.5 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-rose-600 text-[9px] font-bold text-white ring-1 ring-white">
                    !
                  </span>
                )}
              </div>

              {/* Small tooltip label */}
              <div
                className={`mt-1 rounded-md px-2 py-0.5 text-[10px] font-semibold tracking-tight shadow-sm whitespace-nowrap transition-all border ${
                  isSelected
                    ? 'bg-indigo-600 border-indigo-600 text-white'
                    : 'bg-slate-800/90 border-slate-700 text-slate-100 dark:bg-slate-950 dark:border-slate-800'
                }`}
              >
                {center.name.split(' ')[0]} ({center.type})
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
