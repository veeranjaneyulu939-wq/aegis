/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HealthCenter, OperationalAlert } from '../types';
import { 
  Shield, 
  Plus, 
  AlertTriangle, 
  Users, 
  BedDouble, 
  AlertCircle, 
  TrendingUp, 
  CheckCircle, 
  Flame, 
  ServerCrash,
  Database,
  Edit,
  RefreshCw,
  X,
  Check,
  Activity
} from 'lucide-react';

interface MetricsDashboardProps {
  centers: HealthCenter[];
  alerts: OperationalAlert[];
  selectedCenterId: string;
  onSelectCenter: (id: string) => void;
  onUpdateCenter?: (center: HealthCenter) => void;
  onAddCenter?: (center: HealthCenter) => void;
  onResetDatabase?: () => void;
}

export default function MetricsDashboard({
  centers,
  alerts,
  selectedCenterId,
  onSelectCenter,
  onUpdateCenter,
  onAddCenter,
  onResetDatabase,
}: MetricsDashboardProps) {
  // Modal states
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);

  // Edit fields state
  const [editPatientFlow, setEditPatientFlow] = useState(0);
  const [editPatientFlowTrend, setEditPatientFlowTrend] = useState<'steady' | 'rising' | 'falling'>('steady');
  const [editBedOccupancy, setEditBedOccupancy] = useState(0);
  const [editDoctorsAvailable, setEditDoctorsAvailable] = useState(0);
  const [editDoctorsTotal, setEditDoctorsTotal] = useState(0);
  const [editLabServicesActive, setEditLabServicesActive] = useState(true);
  const [editInventoryStocks, setEditInventoryStocks] = useState<{ [key: string]: number }>({});

  // Add fields state
  const [addId, setAddId] = useState('');
  const [addName, setAddName] = useState('');
  const [addType, setAddType] = useState<'PHC' | 'CHC'>('PHC');
  const [addLocationX, setAddLocationX] = useState(50);
  const [addLocationY, setAddLocationY] = useState(50);
  const [addPatientFlow, setAddPatientFlow] = useState(120);
  const [addBedOccupancy, setAddBedOccupancy] = useState(65);
  const [addDoctorsAvailable, setAddDoctorsAvailable] = useState(3);
  const [addDoctorsTotal, setAddDoctorsTotal] = useState(4);
  const [addLabServicesActive, setAddLabServicesActive] = useState(true);

  // Compute some high-level metrics
  const totalDoctorsAvailable = centers.reduce((acc, c) => acc + c.doctorsAvailable, 0);
  const totalDoctorsTotal = centers.reduce((acc, c) => acc + c.doctorsTotal, 0);
  const avgBedOccupancy = Math.round(centers.reduce((acc, c) => acc + c.bedOccupancy, 0) / (centers.length || 1));
  
  const criticalItemsCount = centers.reduce((acc, c) => {
    return acc + Object.values(c.inventory).filter(i => i.status === 'critical').length;
  }, 0);

  const selectedCenter = centers.find(c => c.id === selectedCenterId) || centers[0];

  const getAlertIcon = (type: string, severity: string) => {
    if (severity === 'critical') {
      return <Flame className="h-4.5 w-4.5 text-rose-500 animate-pulse" />;
    }
    return <AlertTriangle className="h-4.5 w-4.5 text-amber-500" />;
  };

  const getAlertBg = (severity: string) => {
    return severity === 'critical'
      ? 'bg-rose-500/5 border-rose-500/15 text-rose-800 dark:text-rose-300 dark:border-rose-950/50'
      : 'bg-amber-500/5 border-amber-500/15 text-amber-800 dark:text-amber-300 dark:border-amber-950/50';
  };

  const getStockStatusColor = (status: string) => {
    if (status === 'critical') return 'text-rose-500 font-bold';
    if (status === 'warning') return 'text-amber-500 font-semibold';
    return 'text-emerald-500';
  };

  const getProgressBarColor = (status: string) => {
    if (status === 'critical') return 'bg-rose-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]';
    if (status === 'warning') return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const handleSaveEdit = () => {
    if (!onUpdateCenter || !selectedCenter) return;
    
    // Construct updated inventory
    const updatedInventory = { ...selectedCenter.inventory };
    Object.keys(updatedInventory).forEach(itemName => {
      if (editInventoryStocks[itemName] !== undefined) {
        const newStock = Number(editInventoryStocks[itemName]);
        const minRequired = updatedInventory[itemName].minRequired;
        
        let status: 'optimal' | 'warning' | 'critical' = 'optimal';
        if (newStock < minRequired * 0.4) {
          status = 'critical';
        } else if (newStock < minRequired) {
          status = 'warning';
        }
        
        const depletionDays = Math.max(1, Math.round((newStock / (minRequired || 1)) * 14));
        
        updatedInventory[itemName] = {
          ...updatedInventory[itemName],
          stock: newStock,
          status,
          depletionDays,
        };
      }
    });

    const updatedCenter: HealthCenter = {
      ...selectedCenter,
      patientFlow: Number(editPatientFlow),
      patientFlowTrend: editPatientFlowTrend,
      bedOccupancy: Number(editBedOccupancy),
      doctorsAvailable: Number(editDoctorsAvailable),
      doctorsTotal: Number(editDoctorsTotal),
      labServicesActive: editLabServicesActive,
      inventory: updatedInventory,
    };

    onUpdateCenter(updatedCenter);
    setIsEditOpen(false);
  };

  const handleSaveAdd = () => {
    if (!onAddCenter) return;
    if (!addId.trim() || !addName.trim()) {
      alert('Please provide a unique ID and Name for the new health facility.');
      return;
    }

    const finalId = addId.trim().toLowerCase().replace(/\s+/g, '-');

    // Standard clinical inventory baseline template
    const defaultInventory = {
      'Amoxicillin': { name: 'Amoxicillin', stock: 250, minRequired: 150, unit: 'vials', depletionDays: 18, status: 'optimal' as const },
      'Paracetamol': { name: 'Paracetamol', stock: 600, minRequired: 300, unit: 'tablets', depletionDays: 24, status: 'optimal' as const },
      'ORS Packets': { name: 'ORS Packets', stock: 450, minRequired: 250, unit: 'packets', depletionDays: 20, status: 'optimal' as const },
      'IV Saline': { name: 'IV Saline', stock: 90, minRequired: 100, unit: 'bottles', depletionDays: 12, status: 'warning' as const },
    };

    const newCenter: HealthCenter = {
      id: finalId,
      name: addName.trim(),
      type: addType,
      location: { x: Number(addLocationX), y: Number(addLocationY) },
      patientFlow: Number(addPatientFlow),
      patientFlowTrend: 'steady',
      bedOccupancy: Number(addBedOccupancy),
      doctorsAvailable: Number(addDoctorsAvailable),
      doctorsTotal: Number(addDoctorsTotal),
      labServicesActive: addLabServicesActive,
      inventory: defaultInventory,
    };

    onAddCenter(newCenter);
    setIsAddOpen(false);
    
    // Reset state inputs
    setAddId('');
    setAddName('');
    setAddType('PHC');
    setAddLocationX(Math.round(20 + Math.random() * 60));
    setAddLocationY(Math.round(20 + Math.random() * 60));
  };

  const openEditModal = () => {
    if (!selectedCenter) return;
    setEditPatientFlow(selectedCenter.patientFlow);
    setEditPatientFlowTrend(selectedCenter.patientFlowTrend);
    setEditBedOccupancy(selectedCenter.bedOccupancy);
    setEditDoctorsAvailable(selectedCenter.doctorsAvailable);
    setEditDoctorsTotal(selectedCenter.doctorsTotal);
    setEditLabServicesActive(selectedCenter.labServicesActive);
    
    const initialInv: { [key: string]: number } = {};
    Object.entries(selectedCenter.inventory).forEach(([k, v]) => {
      initialInv[k] = v.stock;
    });
    setEditInventoryStocks(initialInv);
    setIsEditOpen(true);
  };

  return (
    <div id="metrics-dashboard-container" className="flex flex-col gap-6">
      {/* 4 Overview stat cards */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {/* Stat 1: Avg Bed Occupancy */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900/50">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400">Bed Occupancy</span>
            <BedDouble className="h-4.5 w-4.5 text-indigo-500" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-1">
            <span className="font-sans text-2xl font-bold tracking-tight text-slate-800 dark:text-slate-100">
              {avgBedOccupancy}%
            </span>
            <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">Avg across district</span>
          </div>
        </div>

        {/* Stat 2: Doctors On-Duty */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900/50">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400">Doctor Presence</span>
            <Users className="h-4.5 w-4.5 text-indigo-500" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-1">
            <span className="font-sans text-2xl font-bold tracking-tight text-slate-800 dark:text-slate-100">
              {totalDoctorsAvailable}/{totalDoctorsTotal}
            </span>
            <span className="font-mono text-[10px] text-emerald-500 font-semibold">Active Duty</span>
          </div>
        </div>

        {/* Stat 3: Predicted Stockouts */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900/50">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400">Predicted Stockouts</span>
            <AlertCircle className="h-4.5 w-4.5 text-rose-500" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-1">
            <span className={`font-sans text-2xl font-bold tracking-tight ${criticalItemsCount > 0 ? 'text-rose-500 animate-pulse' : 'text-slate-800 dark:text-slate-100'}`}>
              {criticalItemsCount}
            </span>
            <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">{"< 3 days remaining"}</span>
          </div>
        </div>

        {/* Stat 4: Active Operations alerts */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900/50">
          <div className="flex items-center justify-between">
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400">Active Warnings</span>
            <AlertTriangle className="h-4.5 w-4.5 text-amber-500" />
          </div>
          <div className="mt-2.5 flex items-baseline gap-1">
            <span className="font-sans text-2xl font-bold tracking-tight text-slate-800 dark:text-slate-100">
              {alerts.length}
            </span>
            <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">Real-time indicators</span>
          </div>
        </div>
      </div>

      {/* Cloud Database Actions Panel */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900/50">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
            <Database className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-sans text-xs font-bold text-slate-800 dark:text-slate-100 uppercase tracking-tight">Cloud Database Controls</h4>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">Store and organize persistent regional facilities in Firestore</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsAddOpen(true)}
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-xs transition-all hover:bg-indigo-500 active:scale-95 cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Add New Facility</span>
          </button>
          {onResetDatabase && (
            <button
              onClick={() => {
                if (confirm('Are you sure you want to reset the Firestore database? This will purge all current data and seed default values.')) {
                  onResetDatabase();
                }
              }}
              className="flex items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-500/5 px-3.5 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-500/10 transition-all active:scale-95 cursor-pointer dark:border-rose-950 dark:text-rose-400"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Reset Database</span>
            </button>
          )}
        </div>
      </div>

      {/* Grid: Selected Center Inventory Detail & Active District Alerts Feed */}
      <div className="grid gap-6 md:grid-cols-5">
        
        {/* Selected Center Detailed Inventory - taking 3 cols */}
        <div className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900/50 md:col-span-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
            <div>
              <h4 className="font-sans text-sm font-bold text-slate-800 dark:text-slate-100">
                {selectedCenter?.name || 'Clinic'} Stock Status
              </h4>
              <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500 uppercase">
                Interactive clinic catalog & replenishment thresholds
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                onClick={openEditModal}
                className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition-all dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 cursor-pointer"
              >
                <Edit className="h-3 w-3 text-indigo-500" />
                <span>Edit Parameters</span>
              </button>
              <span className="font-mono text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded-md">
                {selectedCenter?.type === 'CHC' ? 'COMMUNITY HUB' : 'SATELLITE CLINIC'}
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-4 pt-1">
            {selectedCenter && Object.values(selectedCenter.inventory).map(item => {
              const stockRatio = Math.min((item.stock / item.minRequired) * 100, 100);
              return (
                <div key={item.name} className="flex flex-col gap-1.5 border-b border-slate-50 pb-3 last:border-0 last:pb-0 dark:border-slate-800/40">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-sans font-semibold text-slate-700 dark:text-slate-200">
                      {item.name}
                    </span>
                    <span className={`font-mono text-[11px] ${getStockStatusColor(item.status)}`}>
                      {item.stock} {item.unit} ({item.depletionDays}d left)
                    </span>
                  </div>

                  {/* Micro Progress bar */}
                  <div className="relative h-2 w-full rounded-full bg-slate-100 dark:bg-slate-800">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${getProgressBarColor(item.status)}`}
                      style={{ width: `${stockRatio}%` }}
                    />
                  </div>

                  {/* Detailed metrics footer */}
                  <div className="flex justify-between font-mono text-[9px] text-slate-400 dark:text-slate-500">
                    <span>Threshold: {item.minRequired} {item.unit}</span>
                    <span>Status: <strong className="uppercase">{item.status}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Real-time Alerts feed - taking 2 cols */}
        <div className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900/50 md:col-span-2">
          <div className="border-b border-slate-100 pb-3 dark:border-slate-800">
            <h4 className="font-sans text-sm font-bold text-slate-800 dark:text-slate-100">
              Active Warning Feeds
            </h4>
            <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500 uppercase">
              District-wide telemetry alerts
            </p>
          </div>

          <div className="flex max-h-[340px] flex-col gap-3 overflow-y-auto pr-1">
            {alerts.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-2 py-12 text-center">
                <CheckCircle className="h-7 w-7 text-emerald-500" />
                <span className="font-sans text-xs text-slate-500 dark:text-slate-400">All feeds optimal</span>
              </div>
            ) : (
              alerts.map(alert => (
                <div
                  key={alert.id}
                  onClick={() => onSelectCenter(alert.centerId)}
                  className={`cursor-pointer rounded-xl border p-3 shadow-xs transition-all hover:scale-[1.01] ${getAlertBg(alert.severity)}`}
                >
                  <div className="flex items-center gap-2">
                    {getAlertIcon(alert.type, alert.severity)}
                    <span className="font-sans text-xs font-bold truncate">
                      {alert.centerName}
                    </span>
                  </div>
                  <p className="mt-1 font-sans text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {alert.message}
                  </p>
                  <div className="mt-2.5 rounded-md bg-white/50 dark:bg-slate-950/20 px-2 py-1 font-sans text-[10px] text-slate-500 dark:text-slate-400">
                    <strong>Rec:</strong> {alert.recommendedAction}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* MODAL 1: Edit Clinical/Inventory Parameters */}
      <AnimatePresence>
        {isEditOpen && selectedCenter && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl dark:border-slate-800 dark:bg-slate-900"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/30">
                <div className="flex items-center gap-2">
                  <Edit className="h-4.5 w-4.5 text-indigo-500" />
                  <h3 className="font-sans text-sm font-bold text-slate-800 dark:text-slate-100">
                    Edit {selectedCenter.name}
                  </h3>
                </div>
                <button 
                  onClick={() => setIsEditOpen(false)}
                  className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Form body */}
              <div className="max-h-[70vh] overflow-y-auto p-5 space-y-4">
                
                {/* Section: Operational Stats */}
                <div>
                  <h4 className="font-mono text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2.5">
                    Clinical Telemetry
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                        Patient Inflow (per day)
                      </label>
                      <input 
                        type="number" 
                        value={editPatientFlow}
                        onChange={(e) => setEditPatientFlow(Number(e.target.value))}
                        className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                        Inflow Trend
                      </label>
                      <select 
                        value={editPatientFlowTrend}
                        onChange={(e) => setEditPatientFlowTrend(e.target.value as any)}
                        className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-sans text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                      >
                        <option value="steady">Steady (→)</option>
                        <option value="rising">Rising (↑)</option>
                        <option value="falling">Falling (↓)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                        Bed Occupancy (%)
                      </label>
                      <input 
                        type="number" 
                        min="0"
                        max="100"
                        value={editBedOccupancy}
                        onChange={(e) => setEditBedOccupancy(Number(e.target.value))}
                        className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                        Lab Diagnostics
                      </label>
                      <select 
                        value={editLabServicesActive ? "true" : "false"}
                        onChange={(e) => setEditLabServicesActive(e.target.value === "true")}
                        className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-sans text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                      >
                        <option value="true">ONLINE / ACTIVE</option>
                        <option value="false">OFFLINE / OUTAGE</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                        Physicians Available
                      </label>
                      <input 
                        type="number" 
                        value={editDoctorsAvailable}
                        onChange={(e) => setEditDoctorsAvailable(Number(e.target.value))}
                        className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                        Physicians Total
                      </label>
                      <input 
                        type="number" 
                        value={editDoctorsTotal}
                        onChange={(e) => setEditDoctorsTotal(Number(e.target.value))}
                        className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                      />
                    </div>
                  </div>
                </div>

                <hr className="border-slate-100 dark:border-slate-800" />

                {/* Section: Inventory stocks */}
                <div>
                  <h4 className="font-mono text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2.5">
                    Medical Stock Inventory Levels
                  </h4>
                  <div className="space-y-3">
                    {Object.values(selectedCenter.inventory).map(item => (
                      <div key={item.name} className="flex items-center justify-between gap-4">
                        <span className="font-sans text-xs font-semibold text-slate-700 dark:text-slate-300">
                          {item.name} ({item.unit})
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[10px] text-slate-400">Min Req: {item.minRequired}</span>
                          <input 
                            type="number"
                            value={editInventoryStocks[item.name] !== undefined ? editInventoryStocks[item.name] : item.stock}
                            onChange={(e) => setEditInventoryStocks({
                              ...editInventoryStocks,
                              [item.name]: Number(e.target.value)
                            })}
                            className="w-24 rounded-lg border border-slate-200 px-2.5 py-1 text-right font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Footer Actions */}
              <div className="flex items-center justify-end gap-2 border-t border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/30">
                <button
                  onClick={() => setIsEditOpen(false)}
                  className="rounded-lg border border-slate-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveEdit}
                  className="flex items-center gap-1 rounded-lg bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white shadow-xs transition-all hover:bg-indigo-500 active:scale-98 cursor-pointer"
                >
                  <Check className="h-3.5 w-3.5" />
                  <span>Save to Database</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* MODAL 2: Add New Facility node */}
      <AnimatePresence>
        {isAddOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl dark:border-slate-800 dark:bg-slate-900"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/30">
                <div className="flex items-center gap-2">
                  <Database className="h-4.5 w-4.5 text-indigo-500" />
                  <h3 className="font-sans text-sm font-bold text-slate-800 dark:text-slate-100">
                    Add Custom Regional Health Node
                  </h3>
                </div>
                <button 
                  onClick={() => setIsAddOpen(false)}
                  className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Form body */}
              <div className="max-h-[70vh] overflow-y-auto p-5 space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Facility Unique ID
                    </label>
                    <input 
                      type="text" 
                      placeholder="e.g. phc-south"
                      value={addId}
                      onChange={(e) => setAddId(e.target.value)}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Facility Display Name
                    </label>
                    <input 
                      type="text" 
                      placeholder="e.g. South Coastal Delta PHC"
                      value={addName}
                      onChange={(e) => setAddName(e.target.value)}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-sans text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Facility Type
                    </label>
                    <select 
                      value={addType}
                      onChange={(e) => setAddType(e.target.value as any)}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-sans text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    >
                      <option value="PHC">Primary Health Centre (PHC)</option>
                      <option value="CHC">Community Health Centre (CHC)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Lab Diagnostics Status
                    </label>
                    <select 
                      value={addLabServicesActive ? "true" : "false"}
                      onChange={(e) => setAddLabServicesActive(e.target.value === "true")}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-sans text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    >
                      <option value="true">ONLINE / INTEGRATED</option>
                      <option value="false">OFFLINE / MAINTENANCE</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Map Location Coordinate X (10 - 90)
                    </label>
                    <input 
                      type="number" 
                      min="10"
                      max="90"
                      value={addLocationX}
                      onChange={(e) => setAddLocationX(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Map Location Coordinate Y (10 - 90)
                    </label>
                    <input 
                      type="number" 
                      min="10"
                      max="90"
                      value={addLocationY}
                      onChange={(e) => setAddLocationY(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                </div>

                <hr className="border-slate-100 dark:border-slate-800" />

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Baseline Patient Flow / Day
                    </label>
                    <input 
                      type="number" 
                      value={addPatientFlow}
                      onChange={(e) => setAddPatientFlow(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Baseline Bed Occupancy (%)
                    </label>
                    <input 
                      type="number" 
                      min="0"
                      max="100"
                      value={addBedOccupancy}
                      onChange={(e) => setAddBedOccupancy(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Physicians Available
                    </label>
                    <input 
                      type="number" 
                      value={addDoctorsAvailable}
                      onChange={(e) => setAddDoctorsAvailable(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1">
                      Physicians Total
                    </label>
                    <input 
                      type="number" 
                      value={addDoctorsTotal}
                      onChange={(e) => setAddDoctorsTotal(Number(e.target.value))}
                      className="w-full rounded-lg border border-slate-200 px-3 py-1.5 font-mono text-xs text-slate-800 outline-none focus:border-indigo-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200"
                    />
                  </div>
                </div>

                <div className="rounded-xl border border-indigo-50 bg-indigo-500/5 p-3 dark:border-indigo-950/40">
                  <span className="font-sans text-[11px] font-bold text-indigo-700 dark:text-indigo-400">Baseline Inventory Enabled</span>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal mt-0.5">
                    Your new health facility will automatically launch with a calibrated operational baseline inventory of Amoxicillin, Paracetamol, ORS Packets, and IV Salines. You can edit stocks anytime!
                  </p>
                </div>
              </div>

              {/* Footer Actions */}
              <div className="flex items-center justify-end gap-2 border-t border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/30">
                <button
                  onClick={() => setIsAddOpen(false)}
                  className="rounded-lg border border-slate-200 bg-white px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveAdd}
                  className="flex items-center gap-1 rounded-lg bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white shadow-xs transition-all hover:bg-indigo-500 active:scale-98 cursor-pointer"
                >
                  <CheckCircle className="h-3.5 w-3.5" />
                  <span>Create & Store Node</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
