/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { HealthCenter, RedistributionTask } from '../types';
import { Navigation, RefreshCw, Send, CheckCircle2, Award, Zap, AlertCircle, Truck } from 'lucide-react';

interface RedistributionPanelProps {
  tasks: RedistributionTask[];
  centers: HealthCenter[];
  isOnline: boolean;
  onExecuteTask: (taskId: string) => void;
  onRequestAIOptimization: () => Promise<void>;
  isOptimizing: boolean;
  optimizationSummary: string;
}

export default function RedistributionPanel({
  tasks,
  centers,
  isOnline,
  onExecuteTask,
  onRequestAIOptimization,
  isOptimizing,
  optimizationSummary,
}: RedistributionPanelProps) {
  const getCenterName = (id: string) => {
    return centers.find(c => c.id === id)?.name || id;
  };

  return (
    <div id="redistribution-panel-container" className="flex flex-col gap-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
            <Zap className="h-5 w-5 text-indigo-500" />
            Predictive Stock Redistribution Centre
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Automate balance adjustments between surpluses and deficits across clinics
          </p>
        </div>
        <button
          onClick={onRequestAIOptimization}
          disabled={isOptimizing}
          className="flex items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50 px-3.5 py-1.5 font-sans text-xs font-semibold text-indigo-600 transition-all hover:bg-indigo-100/80 active:scale-95 disabled:opacity-50 dark:border-indigo-900/50 dark:bg-indigo-950/40 dark:text-indigo-400"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isOptimizing ? 'animate-spin' : ''}`} />
          {isOptimizing ? 'Analyzing District...' : 'Request AI District Optimization'}
        </button>
      </div>

      {optimizationSummary && (
        <div className="rounded-xl border border-indigo-100 bg-indigo-50/20 p-4 dark:border-indigo-950 dark:bg-indigo-950/20">
          <div className="flex items-start gap-2.5">
            <Award className="mt-0.5 h-4.5 w-4.5 shrink-0 text-indigo-500" />
            <div>
              <span className="font-sans text-xs font-bold text-indigo-700 dark:text-indigo-400">AI District Logistics Insights</span>
              <p className="mt-0.5 font-sans text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{optimizationSummary}</p>
            </div>
          </div>
        </div>
      )}

      {/* Grid of suggested transfers */}
      <div className="flex flex-col gap-3">
        <span className="font-mono text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
          Active Recommendations & Deliveries
        </span>

        {tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-slate-200 p-8 text-center dark:border-slate-800">
            <CheckCircle2 className="h-8 w-8 text-emerald-500" />
            <div>
              <span className="font-sans text-sm font-semibold text-slate-700 dark:text-slate-300">District Stock Perfectly Balanced</span>
              <p className="font-sans text-xs text-slate-400 dark:text-slate-500 mt-0.5">
                No medication shortfalls predicted over the immediate logistics interval.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid gap-3.5 md:grid-cols-2">
            {tasks.map(task => {
              const isSuggested = task.status === 'suggested';
              const isTransit = task.status === 'transit';
              const isCompleted = task.status === 'completed';

              return (
                <div
                  key={task.id}
                  className={`flex flex-col justify-between rounded-xl border p-4 shadow-xs transition-all ${
                    isTransit
                      ? 'border-cyan-200 bg-cyan-50/10 dark:border-cyan-900/50 dark:bg-cyan-950/20'
                      : isCompleted
                      ? 'border-emerald-100 bg-emerald-50/10 dark:border-emerald-950/20'
                      : 'border-slate-200 bg-slate-50/30 dark:border-slate-800'
                  }`}
                >
                  <div>
                    {/* Header: Status */}
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] uppercase font-bold tracking-wider text-indigo-500 dark:text-indigo-400">
                        {task.item} TRANSFER
                      </span>
                      <span
                        className={`rounded-full px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wider ${
                          isTransit
                            ? 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 animate-pulse'
                            : isCompleted
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                            : 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                        }`}
                      >
                        {task.status}
                      </span>
                    </div>

                    {/* Logistics Arrow summary */}
                    <div className="my-3 flex items-center justify-between gap-1">
                      <div className="flex-1">
                        <div className="text-[10px] text-slate-400 dark:text-slate-500 uppercase">Source</div>
                        <div className="font-sans text-xs font-semibold text-slate-700 dark:text-slate-200 truncate">
                          {getCenterName(task.sourceId)}
                        </div>
                      </div>
                      <div className="flex flex-col items-center px-2">
                        <span className="font-mono text-xs font-bold text-slate-800 dark:text-slate-200">
                          {task.quantity}
                        </span>
                        <Navigation className="h-3.5 w-3.5 rotate-90 text-slate-400 dark:text-slate-500 my-0.5" />
                        <span className="font-mono text-[8px] text-slate-400 dark:text-slate-500 uppercase">
                          units
                        </span>
                      </div>
                      <div className="flex-1 text-right">
                        <div className="text-[10px] text-slate-400 dark:text-slate-500 uppercase">Recipient</div>
                        <div className="font-sans text-xs font-semibold text-slate-700 dark:text-slate-200 truncate">
                          {getCenterName(task.targetId)}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Action or ETA line */}
                  <div className="border-t border-slate-100/80 pt-2.5 mt-2 dark:border-slate-800/80">
                    {isSuggested && (
                      <button
                        onClick={() => onExecuteTask(task.id)}
                        className="flex w-full items-center justify-center gap-1.5 rounded-lg bg-indigo-600 py-2 text-xs font-semibold text-white shadow-sm transition-all hover:bg-indigo-500 active:scale-98"
                      >
                        <Send className="h-3 w-3" />
                        Approve & Launch Drone Delivery
                      </button>
                    )}

                    {isTransit && (
                      <div className="flex items-center justify-between text-xs font-mono text-cyan-600 dark:text-cyan-400">
                        <span className="flex items-center gap-1">
                          <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500" />
                          </span>
                          Drone in Air
                        </span>
                        <span>ETA: {task.etaSeconds}s</span>
                      </div>
                    )}

                    {isCompleted && (
                      <div className="flex items-center justify-between text-xs text-emerald-600 dark:text-emerald-400 font-sans font-semibold">
                        <span className="flex items-center gap-1">
                          <CheckCircle2 className="h-4 w-4" /> Delivered & Synchronized
                        </span>
                        <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
                          Stock successfully balanced
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
