/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail, 
  GoogleAuthProvider, 
  signInWithPopup 
} from 'firebase/auth';
import { initFirebase } from '../lib/firebase';
import { 
  Shield, 
  Lock, 
  User, 
  Dna, 
  ArrowRight, 
  Sparkles, 
  AlertCircle, 
  Eye, 
  EyeOff, 
  Mail, 
  UserPlus, 
  Key, 
  ArrowLeft, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';

interface LoginPageProps {
  onLogin: (role: string) => void;
  lang: string;
  setLang: (lang: string) => void;
}

export default function LoginPage({ onLogin, lang, setLang }: LoginPageProps) {
  // Navigation states: 'login' | 'signup' | 'forgot'
  const [viewState, setViewState] = useState<'login' | 'signup' | 'forgot'>('login');
  
  const [role, setRole] = useState<'admin' | 'officer'>('admin');
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isDemoFilling, setIsDemoFilling] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // 3D Bootloader screen states
  const [isBooting, setIsBooting] = useState(true);
  const [bootProgress, setBootProgress] = useState(0);
  const [bootStatus, setBootStatus] = useState('Initializing quantum core layers...');
  const [auth, setAuth] = useState<any>(null);

  React.useEffect(() => {
    initFirebase().then(fb => {
      if (fb) {
        setAuth(fb.auth);
      }
    }).catch(err => console.error('Error initializing login firebase auth:', err));
  }, []);

  React.useEffect(() => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 8) + 5;
      if (progress >= 100) {
        progress = 100;
        setBootStatus('Aegis Predictive Health OS loaded.');
        clearInterval(interval);
        setTimeout(() => {
          setIsBooting(false);
        }, 600);
      } else if (progress > 85) {
        setBootStatus('Establishing secure medical corridor mesh...');
      } else if (progress > 60) {
        setBootStatus('Synchronizing regional public health databases...');
      } else if (progress > 35) {
        setBootStatus('Booting epidemiological prediction engines...');
      } else if (progress > 15) {
        setBootStatus('Securing cryptographic satellite relay channels...');
      }
      setBootProgress(progress);
    }, 110);
    return () => clearInterval(interval);
  }, []);

  // Mouse move parameters for the interactive 3D parallax tilt effect
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const box = card.getBoundingClientRect();
    const x = e.clientX - box.left - box.width / 2;
    const y = e.clientY - box.top - box.height / 2;
    
    // Tilt angle constraints (max 10 degrees)
    setRotateX(-y / (box.height / 2) * 10);
    setRotateY(x / (box.width / 2) * 10);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
  };

  // Sign In submit
  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please provide valid login credentials.');
      return;
    }
    setError(null);
    setIsSubmitting(true);
    
    // Check if we are using the demo credentials or a placeholder password
    const isDemoAccount = email === 'director.operations@aegishealth.gov' || email === 'medical.logistics@aegishealth.gov';
    const isPlaceholderPassword = password.includes('•') || password === '••••••••••••';

    if (isDemoAccount || isPlaceholderPassword) {
      console.log('[Aegis Auth] Bypassing real Firebase authentication for simulated demo credentials.');
      setTimeout(() => {
        setIsSubmitting(false);
        onLogin(role);
      }, 800);
      return;
    }

    try {
      if (auth) {
        await signInWithEmailAndPassword(auth, email, password);
        setIsSubmitting(false);
        onLogin(role);
      } else {
        // Local simulation fallback if Firebase config is not fully initialized yet
        console.warn('Firebase Auth is offline or unconfigured. Proceeding with simulated credentials.');
        setTimeout(() => {
          setIsSubmitting(false);
          onLogin(role);
        }, 800);
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setError(err.message || 'Failed to authenticate user credentials.');
    }
  };

  // Sign Up submit
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !password || !confirmPassword) {
      setError('Please complete all registration fields.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setError(null);
    setIsSubmitting(true);

    try {
      if (auth) {
        await createUserWithEmailAndPassword(auth, email, password);
        setIsSubmitting(false);
        setSuccessMessage('Account created successfully on Firebase Auth! You can now log in.');
        setTimeout(() => {
          setViewState('login');
          setSuccessMessage(null);
        }, 2000);
      } else {
        // Fallback simulation
        setTimeout(() => {
          setIsSubmitting(false);
          setSuccessMessage('Account created successfully (local fallback)! You can now log in.');
          setTimeout(() => {
            setViewState('login');
            setSuccessMessage(null);
          }, 2000);
        }, 1200);
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setError(err.message || 'Failed to register account with Firebase Auth.');
    }
  };

  // Forgot Password submit
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter your registered email address.');
      return;
    }
    setError(null);
    setIsSubmitting(true);

    try {
      if (auth) {
        await sendPasswordResetEmail(auth, email);
        setIsSubmitting(false);
        setSuccessMessage('Password reset link has been dispatched to your email via Firebase.');
        setTimeout(() => {
          setViewState('login');
          setSuccessMessage(null);
        }, 3500);
      } else {
        // Fallback simulation
        setTimeout(() => {
          setIsSubmitting(false);
          setSuccessMessage('Password reset instructions simulated (local fallback).');
          setTimeout(() => {
            setViewState('login');
            setSuccessMessage(null);
          }, 3500);
        }, 1400);
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setError(err.message || 'Failed to process password reset request.');
    }
  };

  // Google Sign In Simulation
  const handleGoogleSignIn = async () => {
    setIsSubmitting(true);
    setError(null);
    
    try {
      if (auth) {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
        setIsSubmitting(false);
        onLogin('admin');
      } else {
        // Fallback simulation
        console.warn('Firebase Auth unavailable, simulating Google login.');
        setTimeout(() => {
          setIsSubmitting(false);
          onLogin('admin');
        }, 1000);
      }
    } catch (err: any) {
      setIsSubmitting(false);
      if (err.code === 'auth/popup-blocked') {
        setError('Popup blocked by browser. Please open the applet in a new tab using the top-right button to authenticate with Google.');
      } else {
        setError(err.message || 'Google Sign-In failed.');
      }
    }
  };

  const autoFillDemo = (selectedRole: 'admin' | 'officer') => {
    setIsDemoFilling(true);
    setRole(selectedRole);
    setViewState('login');
    setError(null);
    setTimeout(() => {
      if (selectedRole === 'admin') {
        setEmail('director.operations@aegishealth.gov');
        setPassword('••••••••••••');
      } else {
        setEmail('medical.logistics@aegishealth.gov');
        setPassword('••••••••••••');
      }
      setIsDemoFilling(false);
    }, 400);
  };

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center bg-slate-950 p-4 overflow-hidden selection:bg-indigo-500 selection:text-white">
      {/* Immersive 3D grid backdrops & radial glow meshes */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-35" />
      
      {/* 3D Nebula light rings */}
      <div className="pointer-events-none absolute -top-40 left-1/3 h-[500px] w-[500px] rounded-full bg-indigo-600/10 blur-[120px]" />
      <div className="pointer-events-none absolute -bottom-40 right-1/3 h-[500px] w-[500px] rounded-full bg-cyan-500/10 blur-[120px]" />

      {/* Language Bar */}
      <div className="absolute top-6 right-6 z-30 flex items-center gap-1.5 rounded-xl bg-slate-900/60 border border-slate-800/80 p-1 backdrop-blur-md">
        {['en', 'hi', 'te', 'ta'].map(l => (
          <button
            key={l}
            onClick={() => setLang(l)}
            className={`rounded-lg px-2.5 py-1 text-xs font-bold transition-all ${
              lang === l
                ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {l.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Main Container utilizing 3D Perspective */}
      <div 
        style={{ perspective: '1000px' }}
        className="relative z-10 w-full max-w-[480px]"
      >
        <motion.div
          initial={{ opacity: 0, y: 40, rotateX: 20 }}
          animate={{ 
            opacity: 1, 
            y: 0, 
            rotateX: rotateX,
            rotateY: rotateY,
          }}
          transition={{
            type: 'spring',
            stiffness: 75,
            damping: 18,
          }}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="relative rounded-3xl border border-slate-800/90 bg-slate-900/40 p-8 shadow-2xl backdrop-blur-xl transition-shadow hover:shadow-indigo-500/5"
        >
          {/* Subtle neon outline glow strip */}
          <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-indigo-500 to-cyan-400 opacity-60" />

          {/* Logo & Platform Info */}
          <div className="mb-6 flex flex-col items-center text-center">
            <motion.div 
              whileHover={{ rotate: 360, scale: 1.1 }}
              transition={{ duration: 1.2, ease: 'easeInOut' }}
              className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-500 shadow-lg shadow-indigo-600/20"
            >
              <Dna className="h-8 w-8 text-white" />
              <span className="absolute -bottom-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-indigo-600 border border-slate-900 font-mono text-[8px] font-black text-white">
                v2
              </span>
            </motion.div>

            <h2 className="mt-3.5 font-sans text-2xl font-black tracking-tight text-white">
              AEGIS HEALTH
            </h2>
            <p className="mt-1 font-mono text-[9px] uppercase tracking-widest text-cyan-400">
              INTELLIGENT MEDICAL CORRIDOR MESH
            </p>
          </div>

          <AnimatePresence mode="wait">
            {/* View State 1: SIGN IN */}
            {viewState === 'login' && (
              <motion.div
                key="login-view"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.18 }}
              >
                {/* Tab Selector for Quick Demofill */}
                <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl bg-slate-950/80 p-1 border border-slate-800/50">
                  <button
                    type="button"
                    onClick={() => autoFillDemo('admin')}
                    className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-all ${
                      role === 'admin'
                        ? 'bg-slate-800 text-white shadow-xs'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Shield className="h-3 w-3" />
                    HQ Admin Demo
                  </button>
                  <button
                    type="button"
                    onClick={() => autoFillDemo('officer')}
                    className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-all ${
                      role === 'officer'
                        ? 'bg-slate-800 text-white shadow-xs'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <User className="h-3 w-3" />
                    Logistics Officer
                  </button>
                </div>

                <form onSubmit={handleSignIn} className="flex flex-col gap-4">
                  {/* Email input */}
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[10px] uppercase tracking-wider text-slate-400">
                      Identity Email
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                      <input
                        type="email"
                        value={email}
                        required
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="name@aegishealth.gov"
                        className="w-full rounded-xl border border-slate-800/80 bg-slate-950/50 py-2.5 pl-10 pr-4 text-xs text-white placeholder-slate-600 outline-hidden transition-all focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>
                  </div>

                  {/* Password input */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center justify-between">
                      <label className="font-mono text-[10px] uppercase tracking-wider text-slate-400">
                        Security Cipher
                      </label>
                      <button
                        type="button"
                        onClick={() => setViewState('forgot')}
                        className="font-sans text-[10px] text-indigo-400 hover:text-indigo-300 font-semibold"
                      >
                        Reset Password?
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        required
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full rounded-xl border border-slate-800/80 bg-slate-950/50 py-2.5 pl-10 pr-10 text-xs text-white placeholder-slate-600 outline-hidden transition-all focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {error && (
                    <div className="flex items-center gap-2 rounded-lg border border-rose-500/10 bg-rose-500/5 px-3 py-2 text-xs text-rose-400">
                      <AlertCircle className="h-4 w-4 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {successMessage && (
                    <div className="flex items-center gap-2 rounded-lg border border-emerald-500/10 bg-emerald-50/5 px-3 py-2 text-xs text-emerald-400">
                      <CheckCircle className="h-4 w-4 shrink-0 animate-bounce" />
                      <span>{successMessage}</span>
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting || isDemoFilling}
                    className="group relative mt-1 flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 py-3 text-xs font-bold text-white shadow-md shadow-indigo-600/15 transition-all hover:from-indigo-500 hover:to-indigo-600 active:scale-98 disabled:opacity-50"
                  >
                    <span>{isSubmitting ? 'Authenticating...' : 'Initialize Operations Core'}</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </button>
                </form>

                {/* Federated Separator */}
                <div className="relative my-5 flex items-center justify-center">
                  <div className="absolute inset-x-0 h-px bg-slate-800/80" />
                  <span className="relative bg-slate-900/40 px-3 font-mono text-[9px] uppercase tracking-widest text-slate-500">
                    Secure SSO Alternatives
                  </span>
                </div>

                {/* Google Sign In Button */}
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isSubmitting}
                  className="flex w-full items-center justify-center gap-2.5 rounded-xl border border-slate-800/80 bg-slate-950/40 py-2.5 text-xs font-semibold text-slate-200 transition-all hover:bg-slate-900/60 active:scale-98 disabled:opacity-50"
                >
                  {/* Styled Vector Google Symbol */}
                  <svg className="h-4.5 w-4.5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#EA4335"
                      d="M5.266 9.765A7.077 7.077 0 0112 4.909c1.69 0 3.218.6 4.418 1.582L19.9 3.01C17.782 1.145 15.055 0 12 0 7.37 0 3.392 2.668 1.455 6.555L5.266 9.765z"
                    />
                    <path
                      fill="#34A853"
                      d="M16.04 15.345c-1.013.678-2.332 1.082-4.04 1.082a7.073 7.073 0 01-6.734-4.856L1.455 14.78C3.392 18.668 7.37 21.336 12 21.336c3.136 0 6.004-1.023 8.164-2.782l-4.124-3.21z"
                    />
                    <path
                      fill="#4285F4"
                      d="M23.491 12.273c0-.8-.073-1.564-.2-2.3H12v4.4h6.44c-.277 1.455-1.1 2.69-2.33 3.518l4.124 3.21c2.413-2.227 3.8-5.51 3.8-9.328z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.266 9.765L1.455 6.555A11.97 11.97 0 000 12c0 1.954.468 3.8 1.455 5.445l3.811-3.21a7.067 7.067 0 010-4.47z"
                    />
                  </svg>
                  <span>Sign in with Google Workspaces</span>
                </button>

                <div className="mt-5 text-center text-[11px] text-slate-400">
                  <span>Don't have an operations profile? </span>
                  <button
                    onClick={() => {
                      setViewState('signup');
                      setError(null);
                    }}
                    className="font-bold text-indigo-400 hover:text-indigo-300 hover:underline"
                  >
                    Request Enrolment
                  </button>
                </div>
              </motion.div>
            )}

            {/* View State 2: REQUEST ENROLMENT / SIGN UP */}
            {viewState === 'signup' && (
              <motion.div
                key="signup-view"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.18 }}
              >
                <div className="mb-4 flex items-center gap-2">
                  <button
                    onClick={() => {
                      setViewState('login');
                      setError(null);
                    }}
                    className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-950/60 border border-slate-800 text-slate-400 hover:text-slate-200"
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </button>
                  <span className="font-sans text-xs font-bold text-slate-300">
                    Return to Operator Gate
                  </span>
                </div>

                <h3 className="mb-4 font-sans text-sm font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <UserPlus className="h-4 w-4 text-indigo-400" />
                  Enrol Medical Operator Account
                </h3>

                <form onSubmit={handleSignUp} className="flex flex-col gap-3.5">
                  {/* Full Name */}
                  <div className="flex flex-col gap-1">
                    <label className="font-mono text-[9px] uppercase tracking-wider text-slate-400">
                      Officer Full Name
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                      <input
                        type="text"
                        value={fullName}
                        required
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="Dr. Sarah Jenkins"
                        className="w-full rounded-xl border border-slate-800/80 bg-slate-950/50 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-600 outline-hidden focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Email */}
                  <div className="flex flex-col gap-1">
                    <label className="font-mono text-[9px] uppercase tracking-wider text-slate-400">
                      Primary Work Email
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                      <input
                        type="email"
                        value={email}
                        required
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="s.jenkins@aegishealth.gov"
                        className="w-full rounded-xl border border-slate-800/80 bg-slate-950/50 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-600 outline-hidden focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div className="flex flex-col gap-1">
                    <label className="font-mono text-[9px] uppercase tracking-wider text-slate-400">
                      Establish Password
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                      <input
                        type="password"
                        value={password}
                        required
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full rounded-xl border border-slate-800/80 bg-slate-950/50 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-600 outline-hidden focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Confirm Password */}
                  <div className="flex flex-col gap-1">
                    <label className="font-mono text-[9px] uppercase tracking-wider text-slate-400">
                      Re-type Cipher
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
                      <input
                        type="password"
                        value={confirmPassword}
                        required
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full rounded-xl border border-slate-800/80 bg-slate-950/50 py-2 pl-9 pr-3 text-xs text-white placeholder-slate-600 outline-hidden focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="flex items-center gap-2 rounded-lg border border-rose-500/10 bg-rose-500/5 px-3 py-2 text-xs text-rose-400">
                      <AlertCircle className="h-4 w-4 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {successMessage && (
                    <div className="flex items-center gap-2 rounded-lg border border-emerald-500/10 bg-emerald-50/5 px-3 py-2 text-xs text-emerald-400">
                      <CheckCircle className="h-4 w-4 shrink-0" />
                      <span>{successMessage}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="group relative mt-2 flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 py-2.5 text-xs font-bold text-white shadow-md shadow-indigo-600/15 transition-all hover:from-indigo-500 active:scale-98"
                  >
                    <span>{isSubmitting ? 'Requesting Clearance...' : 'Enrol Operator Clearance'}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </form>
              </motion.div>
            )}

            {/* View State 3: FORGOT PASSWORD */}
            {viewState === 'forgot' && (
              <motion.div
                key="forgot-view"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.18 }}
              >
                <div className="mb-4 flex items-center gap-2">
                  <button
                    onClick={() => {
                      setViewState('login');
                      setError(null);
                    }}
                    className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-950/60 border border-slate-800 text-slate-400 hover:text-slate-200"
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </button>
                  <span className="font-sans text-xs font-bold text-slate-300">
                    Back to Operator Portal
                  </span>
                </div>

                <h3 className="mb-3 font-sans text-sm font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Key className="h-4 w-4 text-indigo-400" />
                  Recover Access Clearance
                </h3>
                
                <p className="mb-5 font-sans text-[11px] text-slate-400 leading-relaxed">
                  Enter your registered work email to receive an instant verification and recovery link containing your dynamic session security credentials.
                </p>

                <form onSubmit={handleForgotPassword} className="flex flex-col gap-4">
                  {/* Email */}
                  <div className="flex flex-col gap-1.5">
                    <label className="font-mono text-[9px] uppercase tracking-wider text-slate-400">
                      Work Email
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                      <input
                        type="email"
                        value={email}
                        required
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="s.jenkins@aegishealth.gov"
                        className="w-full rounded-xl border border-slate-800/80 bg-slate-950/50 py-2.5 pl-10 pr-4 text-xs text-white placeholder-slate-600 outline-hidden focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="flex items-center gap-2 rounded-lg border border-rose-500/10 bg-rose-500/5 px-3 py-2 text-xs text-rose-400">
                      <AlertCircle className="h-4 w-4 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {successMessage && (
                    <div className="flex items-center gap-2 rounded-lg border border-emerald-500/10 bg-emerald-50/5 px-3 py-2 text-xs text-emerald-400">
                      <CheckCircle className="h-4 w-4 shrink-0" />
                      <span>{successMessage}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="group relative mt-2 flex w-full items-center justify-center gap-2 overflow-hidden rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 py-2.5 text-xs font-bold text-white shadow-md shadow-indigo-600/15 transition-all hover:from-indigo-500 active:scale-98"
                  >
                    <span>{isSubmitting ? 'Transmitting protocol...' : 'Transmit Access Token'}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Quick Demo fill Assist Banner */}
          {viewState === 'login' && (
            <div className="mt-6 text-center">
              <span className="inline-flex items-center gap-1 font-sans text-[11px] text-indigo-400">
                <Sparkles className="h-3 w-3 animate-pulse" />
                Click Admin or Logistics buttons for zero-click entries
              </span>
            </div>
          )}

        </motion.div>
      </div>

      {/* Floating Ambient particle elements to enrich the 3D depth feel */}
      <div className="pointer-events-none mt-8 text-center font-mono text-[9px] text-slate-600 uppercase tracking-widest">
        SECURE SEAMLESS INTERIOR TELEMETRY • CLIENT LAYER 3.5.0
      </div>
    </div>
  );
}
