/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Code, Database, Server, Cpu, Cloud, FileText, ChevronRight, Terminal } from 'lucide-react';

export default function TechnicalSpecsConsole() {
  const [activeTab, setActiveTab] = useState<'srs' | 'database' | 'api' | 'deployment'>('srs');

  const SRS_CONTENT = (
    <div className="flex flex-col gap-4 font-sans text-xs text-slate-600 dark:text-slate-300">
      <div>
        <h4 className="font-sans text-sm font-bold text-slate-800 dark:text-slate-100 uppercase tracking-tight">
          1. Vision & Strategic Problem Statement
        </h4>
        <p className="mt-1 leading-relaxed">
          Public health networks in developing regions struggle with massive stock imbalances. While central warehouses hold surpluses, remote Primary Health Centres (PHCs) run dry of critical antibiotics and life-saving dehydration salts during monsoon outbreaks. Aegis Predictive Health OS establishes a real-time predictive digital twin of the district, balancing resource equity autonomously.
        </p>
      </div>

      <div>
        <h4 className="font-sans text-sm font-bold text-slate-800 dark:text-slate-100 uppercase tracking-tight">
          2. Multi-Agent AI Workflow
        </h4>
        <p className="mt-1 leading-relaxed">
          Using four micro-agents:
        </p>
        <ul className="list-disc pl-5 mt-1 flex flex-col gap-1">
          <li><strong>Medicine AI</strong>: Predicts stock depletion based on seasonal disease vectors.</li>
          <li><strong>Doctor AI</strong>: Dynamically coordinates clinical shifts for surge events.</li>
          <li><strong>Bed AI</strong>: Directs patient overflow and schedules early discharges.</li>
          <li><strong>Lab AI</strong>: Continuously routes laboratory diagnostics around outages.</li>
        </ul>
      </div>
    </div>
  );

  const DATABASE_SCHEMA = `CREATE TABLE health_centers (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(10) CHECK (type IN ('PHC', 'CHC')),
  location_x FLOAT NOT NULL,
  location_y FLOAT NOT NULL,
  patient_flow INT DEFAULT 0,
  bed_occupancy INT DEFAULT 0,
  doctors_available INT NOT NULL,
  doctors_total INT NOT NULL,
  lab_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE medicine_inventory (
  id SERIAL PRIMARY KEY,
  center_id VARCHAR(64) REFERENCES health_centers(id) ON DELETE CASCADE,
  medicine_name VARCHAR(100) NOT NULL,
  stock_count INT NOT NULL,
  min_required INT NOT NULL,
  unit VARCHAR(20) NOT NULL,
  depletion_days INT NOT NULL,
  status VARCHAR(20) DEFAULT 'optimal'
);

CREATE TABLE redistribution_tasks (
  id VARCHAR(64) PRIMARY KEY,
  source_id VARCHAR(64) REFERENCES health_centers(id),
  target_id VARCHAR(64) REFERENCES health_centers(id),
  item_name VARCHAR(100) NOT NULL,
  quantity INT NOT NULL,
  status VARCHAR(20) CHECK (status IN ('suggested', 'transit', 'completed')),
  eta_seconds INT DEFAULT 15,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);`;

  const API_ROUTER = `// Express.js API Router - /api/v2/logistics
import { Router } from 'express';
import { db } from './db/config';

const router = Router();

// 1. Fetch entire clinical digital twin
router.get('/twin/mesh', async (req, res) => {
  const centers = await db.select().from(healthCenters);
  const alerts = await db.select().from(operationalAlerts);
  res.json({ centers, alerts, meshStatus: 'optimal' });
});

// 2. Queue autonomous drone delivery
router.post('/drones/launch', async (req, res) => {
  const { sourceId, targetId, item, quantity } = req.body;
  const task = await db.insert(redistributionTasks).values({
    sourceId,
    targetId,
    itemName: item,
    quantity,
    status: 'transit'
  }).returning();
  
  // Trigger IoT signal to autonomous payload launcher
  res.json({ success: true, task: task[0] });
});`;

  const DEPLOYMENT_CONFIG = `version: '3.8'
services:
  antigravity-api:
    image: antigravity/core-api:v2.0
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://admin:secret@postgres:5432/antigravity
      - GEMINI_API_KEY=\${GEMINI_API_KEY}
    depends_on:
      - postgres
    restart: always

  postgres:
    image: postgres:15-alpine
    environment:
      - POSTGRES_USER=admin
      - POSTGRES_PASSWORD=secret
      - POSTGRES_DB=aegis_health
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"

volumes:
  pgdata:`;

  const getCodeSnippet = () => {
    if (activeTab === 'database') return DATABASE_SCHEMA;
    if (activeTab === 'api') return API_ROUTER;
    return DEPLOYMENT_CONFIG;
  };

  return (
    <div id="technical-specs" className="flex flex-col gap-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div>
        <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
          <Code className="h-5 w-5 text-indigo-500" />
          Technical Blueprint & System Specs
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Review the full Software Requirements Specification (SRS), schemas, and deployment configurations
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-100 dark:border-slate-800">
        <button
          onClick={() => setActiveTab('srs')}
          className={`flex items-center gap-1.5 border-b-2 px-4 py-2.5 font-sans text-xs font-bold transition-all ${
            activeTab === 'srs'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <FileText className="h-4 w-4" />
          SRS Requirements
        </button>
        <button
          onClick={() => setActiveTab('database')}
          className={`flex items-center gap-1.5 border-b-2 px-4 py-2.5 font-sans text-xs font-bold transition-all ${
            activeTab === 'database'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Database className="h-4 w-4" />
          PostgreSQL Schema
        </button>
        <button
          onClick={() => setActiveTab('api')}
          className={`flex items-center gap-1.5 border-b-2 px-4 py-2.5 font-sans text-xs font-bold transition-all ${
            activeTab === 'api'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Server className="h-4 w-4" />
          Express APIs
        </button>
        <button
          onClick={() => setActiveTab('deployment')}
          className={`flex items-center gap-1.5 border-b-2 px-4 py-2.5 font-sans text-xs font-bold transition-all ${
            activeTab === 'deployment'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Cloud className="h-4 w-4" />
          Docker Deployment
        </button>
      </div>

      {/* Content Renderer */}
      <div className="min-h-[180px]">
        {activeTab === 'srs' ? (
          SRS_CONTENT
        ) : (
          <div className="relative rounded-xl bg-slate-950 p-4 border border-slate-800 text-left font-mono text-[10px] text-cyan-400/90 leading-relaxed overflow-x-auto">
            <div className="absolute right-3 top-3 font-sans text-[9px] text-slate-500 uppercase font-black">
              ReadOnly Codeblock
            </div>
            <pre className="whitespace-pre">{getCodeSnippet()}</pre>
          </div>
        )}
      </div>
    </div>
  );
}
