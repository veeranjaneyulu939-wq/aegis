/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Pill, Users, Bed, Microscope, Brain, Terminal, Sparkles, CheckCircle, Play } from 'lucide-react';
import { HealthCenter } from '../types';

interface MultiAgentConsoleProps {
  centers: HealthCenter[];
  onGenerateAction: (agent: string, recommendation: string) => void;
}

interface AgentState {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  color: string;
  status: string;
  thoughtLog: string[];
  recommendation: string;
}

export default function MultiAgentConsole({ centers, onGenerateAction }: MultiAgentConsoleProps) {
  const [activeAgentId, setActiveAgentId] = useState('medicine-ai');
  const [isPlayingThoughts, setIsPlayingThoughts] = useState<{ [key: string]: boolean }>({
    'medicine-ai': true,
    'doctor-ai': false,
    'bed-ai': false,
    'lab-ai': false,
  });

  const [agents, setAgents] = useState<AgentState[]>([
    {
      id: 'medicine-ai',
      name: 'Medicine AI Agent',
      icon: Pill,
      color: 'text-indigo-400 border-indigo-500/30 bg-indigo-500/10',
      status: 'MONITORING DEPLETION VECTORS',
      thoughtLog: [
        '[08:42:15] Scanning district pharmaceutical logs...',
        '[08:42:18] Warning: North Valley PHC Amoxicillin stock at 35 vials (est. 2 days left).',
        '[08:42:21] Analyzing surplus depots: West Hill CHC has 800 vials (22 days supply).',
        '[08:42:25] Recommendation: Route 300 vials of Amoxicillin from West Hill CHC to North Valley PHC.',
      ],
      recommendation: 'Transfer 300 Amoxicillin vials from West Hill CHC immediately.',
    },
    {
      id: 'doctor-ai',
      name: 'Doctor AI Agent',
      icon: Users,
      color: 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10',
      status: 'BALANCING CLINICAL SHIFTS',
      thoughtLog: [
        '[09:12:02] Fetching emergency physician shift schedules...',
        '[09:12:05] Spike detected: East Coast Riverside patient flow increased by 35% this week.',
        '[09:12:08] Current doctor availability: East Coast Riverside has 1/3 doctors online.',
        '[09:12:12] Suggesting mobilization: Dispatch 1 general physician from District HQ for a 48-hour temporary deployment.',
      ],
      recommendation: 'Deploy 1 General Physician from District HQ to East Coast PHC on a temporary surge roster.',
    },
    {
      id: 'bed-ai',
      name: 'Bed AI Agent',
      icon: Bed,
      color: 'text-amber-400 border-amber-500/30 bg-amber-500/10',
      status: 'OCCUPANCY FORECASTING',
      thoughtLog: [
        '[10:01:44] Fetching bed occupancy telemetries...',
        '[10:01:48] Alert: District HQ Hospital & CHC reached 88% bed occupancy.',
        '[10:01:52] Seasonality pattern indicates incoming gastroenteritis wave.',
        '[10:01:55] Action required: Authorize early discharge of stable post-op observations to home monitoring or satellite PHCs.',
      ],
      recommendation: 'Flag 5 low-risk observation beds for early transition to satellite clinical home-health care.',
    },
    {
      id: 'lab-ai',
      name: 'Lab AI Agent',
      icon: Microscope,
      color: 'text-rose-400 border-rose-500/30 bg-rose-500/10',
      status: 'DIAGNOSTIC NETWORK AUDIT',
      thoughtLog: [
        '[11:15:30] Verifying clinical diagnostic laboratory connection points...',
        '[11:15:33] OFFLINE: East Coast Riverside laboratory unit reported critical failure on centrifuge.',
        '[11:15:37] Local reagent supply levels optimal, but local testing is fully bottlenecked.',
        '[11:15:40] Strategy: Route all blood and antigen assays from East Coast Riverside to District HQ lab hubs.',
      ],
      recommendation: 'Initiate Sample Transfer protocol from East Coast Riverside PHC to District HQ.',
    },
  ]);

  // Periodic simulated agent background processing
  useEffect(() => {
    const timer = setInterval(() => {
      setAgents(prev =>
        prev.map(agent => {
          // Generate new logs dynamically to look like real-time agent processing
          const timestamps = new Date().toLocaleTimeString();
          const randomTriggers = [
            `[${timestamps}] Checking sensor synchronization...`,
            `[${timestamps}] Re-running predictive regression parameters...`,
            `[${timestamps}] Live data streams validated against district telemetry.`,
            `[${timestamps}] Secondary confirmation loop verified successfully.`,
          ];
          const randomChoice = randomTriggers[Math.floor(Math.random() * randomTriggers.length)];
          const updatedLogs = [...agent.thoughtLog.slice(1), randomChoice];
          return {
            ...agent,
            thoughtLog: updatedLogs,
          };
        })
      );
    }, 4500);

    return () => clearInterval(timer);
  }, []);

  const currentAgent = agents.find(a => a.id === activeAgentId) || agents[0];
  const CurrentIcon = currentAgent.icon;

  return (
    <div id="multi-agent-console" className="flex flex-col gap-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div>
        <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
          <Brain className="h-5 w-5 text-indigo-500" />
          Aegis Multi-Agent AI Core
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Dedicated AI micro-agents continuously monitoring clinical components in parallel
        </p>
      </div>

      {/* Horizontal Agent Selector */}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {agents.map(agent => {
          const IconComponent = agent.icon;
          const isActive = agent.id === activeAgentId;
          return (
            <button
              key={agent.id}
              onClick={() => setActiveAgentId(agent.id)}
              className={`flex flex-col items-center gap-2 rounded-xl border p-3.5 text-center transition-all ${
                isActive
                  ? 'border-indigo-600 bg-indigo-50/20 text-indigo-600 dark:bg-indigo-950/30 dark:text-indigo-400 ring-2 ring-indigo-500/10'
                  : 'border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-950/20'
              }`}
            >
              <div className={`rounded-lg p-2 ${agent.color}`}>
                <IconComponent className="h-5 w-5" />
              </div>
              <div>
                <div className="font-sans text-xs font-bold leading-tight">{agent.name}</div>
                <div className="font-mono text-[8px] opacity-70 tracking-tight mt-0.5">{agent.status}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Live Active Agent Viewport */}
      <div className="grid gap-6 md:grid-cols-5">
        {/* Terminal/Logs (3 cols) */}
        <div className="flex flex-col gap-2 rounded-xl bg-slate-950 p-4 border border-slate-800 md:col-span-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="flex items-center gap-1.5 font-mono text-[10px] text-slate-400 uppercase tracking-widest">
              <Terminal className="h-3.5 w-3.5 text-cyan-400" />
              AGENT THOUGHT TELEMETRY
            </span>
            <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
          </div>

          <div className="flex flex-col gap-1.5 font-mono text-xs text-cyan-400/90 h-[140px] overflow-y-auto">
            {currentAgent.thoughtLog.map((log, index) => (
              <div key={index} className="leading-relaxed">
                {log}
              </div>
            ))}
          </div>
        </div>

        {/* Explainable AI Action Card (2 cols) */}
        <div className="flex flex-col justify-between rounded-xl border border-indigo-100 bg-indigo-50/15 p-4 dark:border-indigo-950/60 dark:bg-indigo-950/15 md:col-span-2">
          <div>
            <span className="flex items-center gap-1 font-sans text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              <Sparkles className="h-4 w-4 text-indigo-500 animate-pulse" />
              XAI Recommendation
            </span>
            <p className="mt-2 font-sans text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {currentAgent.recommendation}
            </p>
          </div>

          <button
            onClick={() => onGenerateAction(currentAgent.name, currentAgent.recommendation)}
            className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-lg bg-indigo-600 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-indigo-500 transition-all active:scale-98"
          >
            <Play className="h-3 w-3" />
            Deploy Micro-Agent Strategy
          </button>
        </div>
      </div>
    </div>
  );
}
