/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Volume2, Sparkles, Check, Play, Globe } from 'lucide-react';

interface VoiceAssistantProps {
  onVoiceCommand: (command: string) => void;
  lang: string;
}

export default function VoiceAssistant({ onVoiceCommand, lang }: VoiceAssistantProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [voiceText, setVoiceText] = useState('Click a voice pattern to transmit clinical operational command...');
  const [aiSpeechOutput, setAiSpeechOutput] = useState<string | null>(null);

  const SUGGESTED_COMMANDS: { [key: string]: string[] } = {
    en: [
      'Show North Valley PHC shortage details',
      'Optimize Amoxicillin distribution across the district',
      'Query East Coast Riverside lab outage solution',
    ],
    hi: [
      'उत्तर घाटी पीएचसी की कमी के विवरण दिखाएं',
      'पूरे जिले में एमोक्सिसिलिन वितरण को अनुकूलित करें',
      'पूर्वी तट प्रयोगशाला विफलता समाधान की पूछताछ करें',
    ],
    te: [
      'నార్త్ వ్యాలీ PHC కొరత వివరాలను చూపించు',
      'జిల్లావ్యాప్తంగా అమోక్సిసిలిన్ పంపిణీని అనుకూలపరచు',
      'ఈస్ట్ కోస్ట్ లాబ్ అవుటేజ్ పరిష్కారాన్ని అడుగు',
    ],
    ta: [
      'வடக்கு பள்ளத்தாக்கு பிஎச்சி பற்றாக்குறை விவரங்களைக் காட்டு',
      'மாவட்டம் முழுவதும் அமோக்சிசிலின் விநியோகத்தை மேம்படுத்துக',
      'கிழக்கு கடற்கரை ஆய்வக செயலிழப்பு தீர்வை வினவவும்',
    ],
  };

  const getSuggestedCommands = () => {
    return SUGGESTED_COMMANDS[lang] || SUGGESTED_COMMANDS['en'];
  };

  const handleCommandTrigger = (command: string) => {
    setIsRecording(true);
    setVoiceText(`"${command}"`);
    setAiSpeechOutput(null);

    // Simulate sound wave active state
    setTimeout(async () => {
      setIsRecording(false);
      onVoiceCommand(command);

      // Trigger standard AI response synthesis
      try {
        const response = await fetch('/api/gemini/audit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            center: {
              name: 'Voice Assistant Query Hub',
              type: 'CHC',
              patientFlow: 120,
              patientFlowTrend: 'rising',
              bedOccupancy: 80,
              doctorsAvailable: 5,
              doctorsTotal: 8,
              labServicesActive: false,
              inventory: {},
            },
            districtAlerts: [{ message: command }],
          }),
        });

        const data = await response.json();
        setAiSpeechOutput(data.prediction || 'Operational route optimization computed successfully.');
      } catch (err) {
        setAiSpeechOutput('Voice recognition processed. Directing automated logistics vectors to appropriate centers.');
      }
    }, 2000);
  };

  return (
    <div id="voice-assistant-container" className="flex flex-col gap-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div>
        <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
          <Mic className="h-5 w-5 text-indigo-500 animate-pulse" />
          Aegis Multilingual Voice Assistant
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Transmit hands-free operational guidelines and inventory queries instantly
        </p>
      </div>

      {/* Voice wave visualizer box */}
      <div className="relative flex flex-col items-center justify-center rounded-xl bg-slate-950 p-6 border border-slate-800 text-center">
        {isRecording ? (
          <div className="flex items-center justify-center gap-1 h-12 mb-4">
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="w-1 bg-indigo-500 rounded-full"
                animate={{ height: [12, 38, 12] }}
                transition={{
                  duration: 0.6,
                  repeat: Infinity,
                  delay: i * 0.08,
                }}
              />
            ))}
          </div>
        ) : (
          <div className="flex h-12 items-center justify-center mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-900 border border-slate-800 text-indigo-400">
              <MicOff className="h-5 w-5" />
            </div>
          </div>
        )}

        <span className="font-mono text-xs text-indigo-400 font-bold max-w-[320px] truncate">
          {voiceText}
        </span>
      </div>

      {/* Suggestion tags */}
      <div className="flex flex-col gap-2.5">
        <span className="font-mono text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
          Suggested Voice Prompts
        </span>
        <div className="flex flex-col gap-2">
          {getSuggestedCommands().map((cmd, idx) => (
            <button
              key={idx}
              onClick={() => handleCommandTrigger(cmd)}
              disabled={isRecording}
              className="flex items-center justify-between text-left rounded-lg border border-slate-100 bg-slate-50/50 px-3 py-2.5 hover:bg-indigo-50/30 hover:border-indigo-100 dark:border-slate-800 dark:bg-slate-950/20 text-xs font-sans text-slate-700 dark:text-slate-300 transition-all active:scale-99 disabled:opacity-50"
            >
              <span className="truncate pr-4">{cmd}</span>
              <Play className="h-3.5 w-3.5 text-indigo-500 shrink-0" />
            </button>
          ))}
        </div>
      </div>

      {/* Speech Response Playback Card */}
      <AnimatePresence>
        {aiSpeechOutput && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="rounded-xl border border-emerald-100 bg-emerald-50/10 p-4 dark:border-emerald-950/40"
          >
            <div className="flex items-start gap-2.5">
              <Volume2 className="mt-0.5 h-4.5 w-4.5 text-emerald-500 shrink-0 animate-bounce" />
              <div>
                <span className="font-sans text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                  AI AUDIO SYNTHESIS PLAYBACK
                </span>
                <p className="mt-1 font-sans text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {aiSpeechOutput}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
