/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FileDown, CheckCircle, Clock, ShieldCheck, Heart } from 'lucide-react';
import { HealthCenter } from '../types';

interface DistrictReportGeneratorProps {
  centers: HealthCenter[];
}

export default function DistrictReportGenerator({ centers }: DistrictReportGeneratorProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [reportReady, setReportReady] = useState(false);
  const [timestamp, setTimestamp] = useState<string>('');

  const triggerGeneration = () => {
    setIsGenerating(true);
    setReportReady(false);
    setTimeout(() => {
      setIsGenerating(false);
      setReportReady(true);
      setTimestamp(new Date().toLocaleString());
    }, 1800);
  };

  const calculateTotalBeds = () => centers.reduce((acc, c) => acc + c.bedOccupancy, 0);
  const calculateTotalDoctors = () => centers.reduce((acc, c) => acc + c.doctorsAvailable, 0);

  return (
    <div id="district-report-generator" className="flex flex-col gap-5 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div>
        <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
          <FileDown className="h-5 w-5 text-indigo-500" />
          Autonomous District Health Audit
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Generate an instant, unified clinical and pharmaceutical audit compilation for health administrators
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {/* Quick stat card 1 */}
        <div className="rounded-xl border border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/20">
          <div className="font-sans text-[10px] uppercase font-bold tracking-wider text-slate-400">
            Active Healthcare Hubs
          </div>
          <div className="mt-1 font-sans text-2xl font-black text-indigo-600 dark:text-indigo-400">
            {centers.length} PHCs/CHCs
          </div>
        </div>

        {/* Quick stat card 2 */}
        <div className="rounded-xl border border-slate-100 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950/20">
          <div className="font-sans text-[10px] uppercase font-bold tracking-wider text-slate-400">
            Mobilized Physicians
          </div>
          <div className="mt-1 font-sans text-2xl font-black text-cyan-500">
            {calculateTotalDoctors()} / {centers.reduce((acc, c) => acc + c.doctorsTotal, 0)} available
          </div>
        </div>
      </div>

      <button
        onClick={triggerGeneration}
        disabled={isGenerating}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 hover:bg-slate-850 text-white dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-slate-200 py-3 text-xs font-bold transition-all disabled:opacity-50"
      >
        {isGenerating ? (
          <>
            <Clock className="h-4 w-4 animate-spin" />
            <span>Compiling District Data Matrix...</span>
          </>
        ) : (
          <>
            <FileDown className="h-4 w-4" />
            <span>Compile Comprehensive District Audit Report</span>
          </>
        )}
      </button>

      {reportReady && (
        <div className="rounded-xl border border-emerald-150 bg-emerald-50/15 p-4 dark:border-emerald-950/40 dark:bg-emerald-950/10">
          <div className="flex items-start gap-2.5">
            <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
            <div>
              <strong className="font-sans text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                COMPILATION READY
              </strong>
              <p className="mt-0.5 font-sans text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Security Hash and audit compilation stamped on <strong>{timestamp}</strong>.
              </p>

              {/* Printable representation */}
              <div className="mt-3 rounded-lg border border-slate-100 bg-white p-3 shadow-xs dark:border-slate-800 dark:bg-slate-950/50">
                <div className="flex justify-between border-b pb-1.5 border-slate-100 dark:border-slate-800 font-mono text-[9px] uppercase tracking-wider text-slate-400">
                  <span>Aegis Audit Protocol</span>
                  <span>v2.0-STABLE</span>
                </div>
                <div className="mt-2 flex flex-col gap-1 font-sans text-[10px] text-slate-600 dark:text-slate-300">
                  <div className="flex justify-between">
                    <span>District Hub Bed Saturation:</span>
                    <span className="font-bold">{Math.round((calculateTotalBeds() / (centers.length * 50)) * 100)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pharmaceutical Compliance Status:</span>
                    <span className="font-bold text-emerald-500">100% SECURE</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Active Telemetry Corridors:</span>
                    <span className="font-bold">ALL LINKS ESTABLISHED</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
