/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, Flame, AlertCircle, ShieldAlert } from 'lucide-react';

const WEEKLY_TREND_DATA = [
  { week: 'Wk 24', gastroenteritis: 120, malaria: 45, dengue: 30, respiratory: 180 },
  { week: 'Wk 25', gastroenteritis: 150, malaria: 52, dengue: 48, respiratory: 210 },
  { week: 'Wk 26', gastroenteritis: 210, malaria: 65, dengue: 70, respiratory: 240 },
  { week: 'Wk 27', gastroenteritis: 310, malaria: 88, dengue: 110, respiratory: 280 }, // Current Week
  { week: 'Wk 28 (Proj)', gastroenteritis: 420, malaria: 115, dengue: 155, respiratory: 310 }, // Predicted spike
  { week: 'Wk 29 (Proj)', gastroenteritis: 380, malaria: 130, dengue: 140, respiratory: 290 },
  { week: 'Wk 30 (Proj)', gastroenteritis: 250, malaria: 95, dengue: 90, respiratory: 240 },
];

export default function DiseaseTrendTracker() {
  const [selectedDisease, setSelectedDisease] = useState<'all' | 'gastro' | 'malaria' | 'dengue' | 'resp'>('all');
  const [forecastHorizon, setForecastHorizon] = useState<number>(14);

  return (
    <div id="disease-trend-container" className="flex flex-col gap-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900/50">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h3 className="flex items-center gap-2 font-sans text-lg font-semibold tracking-tight text-slate-800 dark:text-slate-100">
            <TrendingUp className="h-5 w-5 text-indigo-500" />
            Epidemiological & Outbreak Predictor
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            AI-driven infectious wave projections based on ambient humidity and clinical logs
          </p>
        </div>

        {/* Outbreak warning badge */}
        <div className="flex items-center gap-1.5 rounded-lg border border-rose-500/20 bg-rose-500/10 px-2.5 py-1 text-xs font-bold text-rose-500 animate-pulse">
          <Flame className="h-4 w-4" />
          <span>Gastro Outbreak Predicted</span>
        </div>
      </div>

      {/* Disease Filters */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setSelectedDisease('all')}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold border transition-all ${
            selectedDisease === 'all'
              ? 'bg-indigo-600 border-indigo-600 text-white'
              : 'border-slate-200 hover:bg-slate-50 dark:border-slate-800'
          }`}
        >
          All Pathologies
        </button>
        <button
          onClick={() => setSelectedDisease('gastro')}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold border transition-all ${
            selectedDisease === 'gastro'
              ? 'bg-rose-500 border-rose-500 text-white'
              : 'border-slate-200 hover:bg-slate-50 dark:border-slate-800'
          }`}
        >
          Gastroenteritis (Monsoon Surge)
        </button>
        <button
          onClick={() => setSelectedDisease('malaria')}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold border transition-all ${
            selectedDisease === 'malaria'
              ? 'bg-amber-500 border-amber-500 text-white'
              : 'border-slate-200 hover:bg-slate-50 dark:border-slate-800'
          }`}
        >
          Malaria (Vector Index)
        </button>
        <button
          onClick={() => setSelectedDisease('dengue')}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold border transition-all ${
            selectedDisease === 'dengue'
              ? 'bg-indigo-500 border-indigo-500 text-white'
              : 'border-slate-200 hover:bg-slate-50 dark:border-slate-800'
          }`}
        >
          Dengue
        </button>
      </div>

      {/* Recharts Graphical Chart */}
      <div className="h-[240px] w-full bg-slate-50/50 p-2 rounded-xl border border-slate-100 dark:bg-slate-950/20 dark:border-slate-800/60">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={WEEKLY_TREND_DATA} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
            <defs>
              <linearGradient id="colorGastro" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorMalaria" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorDengue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
            <XAxis dataKey="week" tick={{ fontSize: 10 }} stroke="#94a3b8" />
            <YAxis tick={{ fontSize: 10 }} stroke="#94a3b8" />
            <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
            <Legend wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
            
            {(selectedDisease === 'all' || selectedDisease === 'gastro') && (
              <Area type="monotone" dataKey="gastroenteritis" name="Gastroenteritis" stroke="#ef4444" strokeWidth={2} fillOpacity={1} fill="url(#colorGastro)" />
            )}
            {(selectedDisease === 'all' || selectedDisease === 'malaria') && (
              <Area type="monotone" dataKey="malaria" name="Malaria" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#colorMalaria)" />
            )}
            {(selectedDisease === 'all' || selectedDisease === 'dengue') && (
              <Area type="monotone" dataKey="dengue" name="Dengue Vector" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorDengue)" />
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Explanatory insights footer */}
      <div className="flex gap-2.5 rounded-xl border border-indigo-100 bg-indigo-50/15 p-3.5 dark:border-indigo-950/60 dark:bg-indigo-950/20">
        <ShieldAlert className="h-5 w-5 text-indigo-500 shrink-0 mt-0.5" />
        <div className="text-xs">
          <strong className="text-indigo-800 dark:text-indigo-400 font-sans">Predictive Model Confidence Index: 94.2%</strong>
          <p className="mt-0.5 font-sans text-slate-600 dark:text-slate-300">
            Incoming heavy monsoons will escalate stagnant water vector counts. We recommend preemptive redistribution of <strong>ORS Packets</strong> to East Coast PHC and Amoxicillin buffers to North Valley PHC within the next 48 hours to secure absolute logistics resiliency.
          </p>
        </div>
      </div>
    </div>
  );
}
