/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface InventoryItem {
  name: string;
  stock: number;
  minRequired: number;
  unit: string;
  depletionDays: number; // Days until stock runs out based on current patient flow
  status: 'optimal' | 'warning' | 'critical';
}

export interface HealthCenter {
  id: string;
  name: string;
  type: 'PHC' | 'CHC';
  location: { x: number; y: number }; // Coordinates on our custom 2D district map
  patientFlow: number; // Current patient count per day
  patientFlowTrend: 'rising' | 'steady' | 'falling';
  bedOccupancy: number; // percentage 0-100
  doctorsAvailable: number;
  doctorsTotal: number;
  labServicesActive: boolean;
  inventory: {
    [key: string]: InventoryItem;
  };
}

export interface RedistributionTask {
  id: string;
  sourceId: string;
  sourceName: string;
  targetId: string;
  targetName: string;
  item: string;
  quantity: number;
  status: 'suggested' | 'transit' | 'completed';
  etaSeconds: number;
}

export interface OperationalAlert {
  id: string;
  centerId: string;
  centerName: string;
  type: 'shortage' | 'patient_surge' | 'staff_deficit' | 'lab_offline';
  severity: 'warning' | 'critical';
  message: string;
  metric: string;
  recommendedAction: string;
}
