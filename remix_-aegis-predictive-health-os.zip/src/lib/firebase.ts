import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

export interface FirebaseAppletConfig {
  projectId: string;
  appId: string;
  apiKey: string;
  authDomain: string;
  firestoreDatabaseId?: string;
  storageBucket?: string;
  messagingSenderId?: string;
}

let app: any = null;
let auth: any = null;
let db: any = null;
let initialized = false;

export async function initFirebase(): Promise<{ auth: any; db: any; config: FirebaseAppletConfig } | null> {
  if (initialized) {
    return { auth, db, config: {} as any };
  }

  try {
    const res = await fetch('/firebase-applet-config.json');
    if (!res.ok) {
      console.warn('Firebase config file could not be retrieved. Aegis running in offline sandbox.');
      return null;
    }
    const config: FirebaseAppletConfig = await res.json();
    if (!config.apiKey || !config.projectId) {
      console.warn('Firebase configuration contains incomplete credentials.');
      return null;
    }

    if (getApps().length > 0) {
      app = getApp();
    } else {
      app = initializeApp({
        apiKey: config.apiKey,
        authDomain: config.authDomain,
        projectId: config.projectId,
        storageBucket: config.storageBucket,
        messagingSenderId: config.messagingSenderId,
        appId: config.appId,
      });
    }

    auth = getAuth(app);
    
    if (config.firestoreDatabaseId) {
      db = getFirestore(app, config.firestoreDatabaseId);
    } else {
      db = getFirestore(app);
    }

    initialized = true;
    console.log('Aegis OS Connected securely to Firestore project:', config.projectId);
    return { auth, db, config };
  } catch (err) {
    console.warn('Failed to connect to Firebase Cloud:', err);
    return null;
  }
}

export function getAuthInstance() {
  return auth;
}

export function getDbInstance() {
  return db;
}
