/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import fs from 'fs';
import { initializeApp, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Default Seeding Datasets
const INITIAL_HEALTH_CENTERS = [
  {
    id: 'chc-hq',
    name: 'District HQ Hospital & CHC',
    type: 'CHC',
    location: { x: 50, y: 50 },
    patientFlow: 180,
    patientFlowTrend: 'rising',
    bedOccupancy: 88,
    doctorsAvailable: 9,
    doctorsTotal: 12,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 1200, minRequired: 400, unit: 'vials', depletionDays: 14, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 350, minRequired: 100, unit: 'vials', depletionDays: 18, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 2500, minRequired: 800, unit: 'sachets', depletionDays: 25, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 3000, minRequired: 600, unit: 'tablets', depletionDays: 20, status: 'optimal' },
    },
  },
  {
    id: 'phc-north',
    name: 'North Valley PHC',
    type: 'PHC',
    location: { x: 30, y: 15 },
    patientFlow: 65,
    patientFlowTrend: 'rising',
    bedOccupancy: 45,
    doctorsAvailable: 2,
    doctorsTotal: 2,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 35, minRequired: 150, unit: 'vials', depletionDays: 2, status: 'critical' },
      Insulin: { name: 'Insulin', stock: 80, minRequired: 50, unit: 'vials', depletionDays: 10, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 900, minRequired: 300, unit: 'sachets', depletionDays: 15, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 450, minRequired: 200, unit: 'tablets', depletionDays: 6, status: 'warning' },
    },
  },
  {
    id: 'phc-east',
    name: 'East Coast Riverside PHC',
    type: 'PHC',
    location: { x: 80, y: 35 },
    patientFlow: 80,
    patientFlowTrend: 'rising',
    bedOccupancy: 92,
    doctorsAvailable: 1,
    doctorsTotal: 3,
    labServicesActive: false,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 250, minRequired: 100, unit: 'vials', depletionDays: 12, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 15, minRequired: 40, unit: 'vials', depletionDays: 3, status: 'critical' },
      ORS: { name: 'ORS Packets', stock: 120, minRequired: 400, unit: 'sachets', depletionDays: 1, status: 'critical' },
      Paracetamol: { name: 'Paracetamol', stock: 1100, minRequired: 300, unit: 'tablets', depletionDays: 14, status: 'optimal' },
    },
  },
  {
    id: 'chc-west',
    name: 'West Hill Foothills CHC',
    type: 'CHC',
    location: { x: 15, y: 65 },
    patientFlow: 110,
    patientFlowTrend: 'steady',
    bedOccupancy: 60,
    doctorsAvailable: 5,
    doctorsTotal: 6,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 800, minRequired: 300, unit: 'vials', depletionDays: 22, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 180, minRequired: 80, unit: 'vials', depletionDays: 15, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 1900, minRequired: 500, unit: 'sachets', depletionDays: 30, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 2400, minRequired: 500, unit: 'tablets', depletionDays: 18, status: 'optimal' },
    },
  },
  {
    id: 'phc-south',
    name: 'South Forest Border PHC',
    type: 'PHC',
    location: { x: 60, y: 80 },
    patientFlow: 45,
    patientFlowTrend: 'falling',
    bedOccupancy: 30,
    doctorsAvailable: 2,
    doctorsTotal: 2,
    labServicesActive: true,
    inventory: {
      Amoxicillin: { name: 'Amoxicillin', stock: 180, minRequired: 100, unit: 'vials', depletionDays: 15, status: 'optimal' },
      Insulin: { name: 'Insulin', stock: 55, minRequired: 30, unit: 'vials', depletionDays: 12, status: 'optimal' },
      ORS: { name: 'ORS Packets', stock: 600, minRequired: 200, unit: 'sachets', depletionDays: 18, status: 'optimal' },
      Paracetamol: { name: 'Paracetamol', stock: 150, minRequired: 150, unit: 'tablets', depletionDays: 3, status: 'warning' },
    },
  },
];

const INITIAL_ALERTS = [
  {
    id: 'alert-1',
    centerId: 'phc-north',
    centerName: 'North Valley PHC',
    type: 'shortage',
    severity: 'critical',
    message: 'Amoxicillin stock (35 vials) is expected to deplete in 2 days based on rising patient flow.',
    metric: 'Medicine Inventory',
    recommendedAction: 'Redistribute 300 vials of Amoxicillin from West Hill Foothills CHC.',
  },
  {
    id: 'alert-2',
    centerId: 'phc-east',
    centerName: 'East Coast Riverside PHC',
    type: 'shortage',
    severity: 'critical',
    message: 'ORS Packets are critically low (120 units left) due to seasonal gastroenteritis spike.',
    metric: 'Medicine Inventory',
    recommendedAction: 'Urgent transfer of 800 ORS sachets from District HQ Hospital.',
  },
  {
    id: 'alert-3',
    centerId: 'phc-east',
    centerName: 'East Coast Riverside PHC',
    type: 'lab_offline',
    severity: 'warning',
    message: 'Primary clinical laboratory reported offline. Blood chemistry diagnostics unavailable.',
    metric: 'Laboratory Services',
    recommendedAction: 'Route emergency lab samples to District HQ Hospital.',
  },
  {
    id: 'alert-4',
    centerId: 'chc-hq',
    centerName: 'District HQ Hospital & CHC',
    type: 'patient_surge',
    severity: 'warning',
    message: 'Bed occupancy reached 88% with an upward trend in emergency admissions.',
    metric: 'Bed Capacity',
    recommendedAction: 'Discharge stable patients or defer elective observations to West Hill Foothills CHC.',
  },
];

const INITIAL_TASKS = [
  {
    id: 'task-1',
    sourceId: 'chc-west',
    sourceName: 'West Hill Foothills CHC',
    targetId: 'phc-north',
    targetName: 'North Valley PHC',
    item: 'Amoxicillin',
    quantity: 300,
    status: 'suggested',
    etaSeconds: 15,
  },
  {
    id: 'task-2',
    sourceId: 'chc-hq',
    sourceName: 'District HQ Hospital & CHC',
    targetId: 'phc-east',
    targetName: 'East Coast Riverside PHC',
    item: 'ORS Packets',
    quantity: 800,
    status: 'suggested',
    etaSeconds: 20,
  },
];

// Initialize Firebase Admin dynamically
let db: any = null;
let useFirebase = false;

try {
  const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    let app;
    if (getApps().length === 0) {
      app = initializeApp({
        projectId: config.projectId,
      });
    } else {
      app = getApps()[0];
    }
    db = getFirestore(app, config.firestoreDatabaseId || undefined);
    useFirebase = true;
    console.log(`[Aegis Backend] Connected securely to Cloud Firestore database: ${config.firestoreDatabaseId || 'default'}`);
  } else {
    console.warn('[Aegis Backend] firebase-applet-config.json not found. Operating with In-Memory Sandbox Mode.');
  }
} catch (error) {
  console.error('[Aegis Backend] Error initializing Firebase Admin, falling back to local storage:', error);
}

// In-Memory Backups (Fallback State Engine)
let localCenters = JSON.parse(JSON.stringify(INITIAL_HEALTH_CENTERS));
let localAlerts = JSON.parse(JSON.stringify(INITIAL_ALERTS));
let localTasks = JSON.parse(JSON.stringify(INITIAL_TASKS));

async function getCenters() {
  if (useFirebase && db) {
    const snap = await db.collection('health_centers').get();
    if (snap.empty) {
      await seedDatabase();
      return INITIAL_HEALTH_CENTERS;
    }
    return snap.docs.map(doc => doc.data());
  }
  return localCenters;
}

async function getAlerts() {
  if (useFirebase && db) {
    const snap = await db.collection('alerts').get();
    return snap.docs.map(doc => doc.data());
  }
  return localAlerts;
}

async function getTasks() {
  if (useFirebase && db) {
    const snap = await db.collection('tasks').get();
    return snap.docs.map(doc => doc.data());
  }
  return localTasks;
}

async function saveCenter(center: any) {
  if (useFirebase && db) {
    await db.collection('health_centers').doc(center.id).set(center);
  } else {
    const index = localCenters.findIndex((c: any) => c.id === center.id);
    if (index !== -1) {
      localCenters[index] = center;
    } else {
      localCenters.push(center);
    }
  }
}

async function saveAlert(alert: any) {
  if (useFirebase && db) {
    await db.collection('alerts').doc(alert.id).set(alert);
  } else {
    const index = localAlerts.findIndex((a: any) => a.id === alert.id);
    if (index !== -1) {
      localAlerts[index] = alert;
    } else {
      localAlerts.push(alert);
    }
  }
}

async function deleteAlert(id: string) {
  if (useFirebase && db) {
    await db.collection('alerts').doc(id).delete();
  } else {
    localAlerts = localAlerts.filter((a: any) => a.id !== id);
  }
}

async function saveTask(task: any) {
  if (useFirebase && db) {
    await db.collection('tasks').doc(task.id).set(task);
  } else {
    const index = localTasks.findIndex((t: any) => t.id === task.id);
    if (index !== -1) {
      localTasks[index] = task;
    } else {
      localTasks.push(task);
    }
  }
}

async function seedDatabase() {
  if (useFirebase && db) {
    console.log('[Aegis Backend] Seeding Firestore with default datasets...');
    const batch = db.batch();
    
    // Seed centers
    for (const center of INITIAL_HEALTH_CENTERS) {
      const ref = db.collection('health_centers').doc(center.id);
      batch.set(ref, center);
    }
    
    // Seed alerts
    for (const alert of INITIAL_ALERTS) {
      const ref = db.collection('alerts').doc(alert.id);
      batch.set(ref, alert);
    }
    
    // Seed tasks
    for (const task of INITIAL_TASKS) {
      const ref = db.collection('tasks').doc(task.id);
      batch.set(ref, task);
    }
    
    await batch.commit();
    console.log('[Aegis Backend] Seeding completed.');
  } else {
    localCenters = JSON.parse(JSON.stringify(INITIAL_HEALTH_CENTERS));
    localAlerts = JSON.parse(JSON.stringify(INITIAL_ALERTS));
    localTasks = JSON.parse(JSON.stringify(INITIAL_TASKS));
  }
}

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('WARNING: GEMINI_API_KEY is not defined. AI features will fallback to automated mock analysis.');
      throw new Error('GEMINI_API_KEY is not configured in this workspace.');
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// REST API Endpoints

// 1. Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Database Synchronization and Persistent Storage Routes

// GET all regional primary/community health facilities
app.get('/api/centers', async (req, res) => {
  try {
    const centers = await getCenters();
    res.json(centers);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// POST or update a health facility record
app.post('/api/centers', async (req, res) => {
  try {
    await saveCenter(req.body);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// GET all warnings and active resource alert notifications
app.get('/api/alerts', async (req, res) => {
  try {
    const alerts = await getAlerts();
    res.json(alerts);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// POST or update an active operational alert
app.post('/api/alerts', async (req, res) => {
  try {
    await saveAlert(req.body);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE a specific operational alert when resolved
app.delete('/api/alerts/:id', async (req, res) => {
  try {
    await deleteAlert(req.params.id);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// GET all medicine redistribution tasks
app.get('/api/tasks', async (req, res) => {
  try {
    const tasks = await getTasks();
    res.json(tasks);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// POST or update a medicine redistribution task
app.post('/api/tasks', async (req, res) => {
  try {
    await saveTask(req.body);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// POST reset to purge and seed standard database values
app.post('/api/reset', async (req, res) => {
  try {
    await seedDatabase();
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// 2. Center Audit Endpoint (using Gemini 3.5 Flash)
app.post('/api/gemini/audit', async (req: express.Request, res: express.Response) => {
  try {
    const { center, districtAlerts } = req.body;
    if (!center) {
       res.status(400).json({ error: 'Center details are required.' });
       return;
    }

    const client = getGeminiClient();

    const systemPrompt = `You are "Antigravity Operations AI", an advanced, predictive clinical operations and logistics officer designed for district-level public health management.
Your purpose is to analyze Primary Health Centres (PHCs) and Community Health Centres (CHCs), predict shortages, and recommend operational adjustments.
Be highly professional, data-centric, and clear. Avoid generic waffle. Keep output structured with action items.`;

    const prompt = `Analyze this health facility's operational metrics and generate a predictive clinical operations audit.

FACILITY DATA:
- Name: ${center.name}
- Type: ${center.type} (PHC = smaller clinic, CHC = larger district hub)
- Patient Flow: ${center.patientFlow} patients/day (${center.patientFlowTrend} trend)
- Bed Occupancy: ${center.bedOccupancy}%
- Staffing: ${center.doctorsAvailable}/${center.doctorsTotal} doctors available
- Lab Status: ${center.labServicesActive ? 'ONLINE' : 'OFFLINE (OUTAGE)'}

MEDICINE INVENTORY:
${Object.values(center.inventory || {})
  .map(
    (item: any) =>
      `- ${item.name}: ${item.stock} ${item.unit} (Min requirement: ${item.minRequired}, Days until depleted: ${item.depletionDays} days, Status: ${item.status})`
  )
  .join('\n')}

DISTRICT CONTEXT & ACTIVE ALERTS:
${JSON.stringify(districtAlerts || [])}

Perform an operational audit and output a JSON object containing the following keys (strict schema):
- "riskLevel": ("low" | "medium" | "high")
- "prediction": "a concise 1-2 sentence forecast of operational bottlenecks over the next 14 days"
- "criticalShortages": ["array", "of", "items", "needing", "immediate", "restock"]
- "redistributionStrategy": "concrete logic for how to balance inventory (e.g. source from who, send what, transport advice)"
- "labStaffingContingency": "action plan if lab is offline or staffing is low"
- "actionItems": ["3-4 clear, bulleted steps with timeline like 'Immediate', '24-hours', 'Next 3 days'"]
`;

    const response = await client.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskLevel: { type: Type.STRING, description: "Risk level of the facility: low, medium, or high" },
            prediction: { type: Type.STRING, description: "Predictive analysis of the next 14 days" },
            criticalShortages: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Items in critical shortage"
            },
            redistributionStrategy: { type: Type.STRING, description: "Logistics and redistribution recommendation" },
            labStaffingContingency: { type: Type.STRING, description: "Strategy for staffing or clinical lab outages" },
            actionItems: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Detailed immediate action items with timeline tags"
            },
          },
          required: ["riskLevel", "prediction", "criticalShortages", "redistributionStrategy", "labStaffingContingency", "actionItems"],
        }
      }
    });

    const auditData = JSON.parse(response.text?.trim() || '{}');
    res.json(auditData);
  } catch (error: any) {
    console.error('Gemini Audit API error:', error);
    // Graceful fallback when Gemini is unavailable or key is unconfigured
    res.json({
      fallback: true,
      riskLevel: 'medium',
      prediction: 'Automated predictive scan suggests potential resource stretch within 7 days due to rising patient flow.',
      criticalShortages: ['Local API key missing. Enter GEMINI_API_KEY to activate full AI analytics.'],
      redistributionStrategy: 'Default protocol: balance inventory relative to nearest CHC.',
      labStaffingContingency: 'Redistribute patient diagnostic samples to adjacent network laboratories.',
      actionItems: [
        'Verify medicine inventory status manually [Immediate]',
        'Ensure power backups for critical refrigeration [Next 24 hours]',
        'Configure GEMINI_API_KEY in secrets tab for real predictive modeling [Optional]',
      ],
    });
  }
});

// 3. District-wide Cross-Center Redistribution Strategy Endpoint
app.post('/api/gemini/recommendations', async (req: express.Request, res: express.Response) => {
  try {
    const { healthCenters, activeAlerts } = req.body;
    if (!healthCenters) {
       res.status(400).json({ error: 'Health center list is required.' });
       return;
    }

    const client = getGeminiClient();

    const systemPrompt = `You are "Antigravity Operations AI".
Your purpose is to read a district-wide list of health centers, find inventory imbalances (surpluses vs. deficits) and suggest optimal stock redistribution routes to prevent stockouts and waste.`;

    const prompt = `Review the list of primary health centers (PHCs) and community health centers (CHCs) in our district and determine a smart inventory redistribution plan.

HEALTH CENTER POOL:
${JSON.stringify(healthCenters, null, 2)}

ACTIVE ALERTS:
${JSON.stringify(activeAlerts, null, 2)}

Provide an automated redistribution recommendation. Output a JSON object containing the following keys (strict schema):
- "strategicSummary": "a high-level summary of district health equity and inventory balance status"
- "proposedTransfers": Array of transfers. Each transfer object must have:
  - "sourceId": ID of center with surplus
  - "sourceName": name of center with surplus
  - "targetId": ID of center in deficit
  - "targetName": name of center in deficit
  - "item": name of medicine
  - "quantity": amount to move (integer)
  - "priority": "high", "medium" or "low"
  - "justification": "why we are transferring this specific quantity"
`;

    const response = await client.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            strategicSummary: { type: Type.STRING },
            proposedTransfers: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  sourceId: { type: Type.STRING },
                  sourceName: { type: Type.STRING },
                  targetId: { type: Type.STRING },
                  targetName: { type: Type.STRING },
                  item: { type: Type.STRING },
                  quantity: { type: Type.INTEGER },
                  priority: { type: Type.STRING },
                  justification: { type: Type.STRING }
                },
                required: ["sourceId", "sourceName", "targetId", "targetName", "item", "quantity", "priority", "justification"]
              }
            }
          },
          required: ["strategicSummary", "proposedTransfers"]
        }
      }
    });

    const recommendations = JSON.parse(response.text?.trim() || '{}');
    res.json(recommendations);
  } catch (error: any) {
    console.error('Gemini Recommendations API error:', error);
    // Fallback transfers
    res.json({
      fallback: true,
      strategicSummary: 'Automated heuristics detected critical shortages of Amoxicillin and ORS. Active redistribution suggested based on location vectors.',
      proposedTransfers: [
        {
          sourceId: 'chc-west',
          sourceName: 'West Hill Foothills CHC',
          targetId: 'phc-north',
          targetName: 'North Valley PHC',
          item: 'Amoxicillin',
          quantity: 250,
          priority: 'high',
          justification: 'West Hill has a 22-day surplus while North Valley is on its final 2-day supply of antibiotic vials.',
        },
        {
          sourceId: 'chc-hq',
          sourceName: 'District HQ Hospital & CHC',
          targetId: 'phc-east',
          targetName: 'East Coast Riverside PHC',
          item: 'ORS Packets',
          quantity: 600,
          priority: 'high',
          justification: 'District HQ holds a massive buffer stock of ORS, whereas East Coast Riverside is down to a single-day supply amid gastroenteritis monsoon alerts.',
        }
      ]
    });
  }
});


// Express server configuration with Vite Integration

async function startServer() {
  // Mount Vite middleware for development or serve index.html in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('Running Express server in DEVELOPMENT mode with Vite middleware');
  } else {
    console.log('Running Express server in PRODUCTION mode');
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Antigravity platform running on http://localhost:${PORT}`);
  });
}

startServer();
